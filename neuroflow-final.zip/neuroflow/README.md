# NeuroFlow

> Think Clearer. Plan Better. Live Smarter.

A premium AI-powered personal operating system combining tasks, finances, cognitive health, sleep tracking, and AI assistance.

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS + CSS Variables (dark/light mode)
- **Database & Auth**: Supabase
- **Charts**: Recharts
- **AI**: OpenAI GPT-4o with Function Calling
- **Email**: Resend
- **Deploy**: Vercel

---

## Quick Start

### 1. Clone & Install

```bash
git clone <your-repo>
cd neuroflow
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env.local
```

Fill in `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### 3. Set Up Supabase

1. Create project at [supabase.com](https://supabase.com)
2. Go to **SQL Editor** and run `schema.sql`
3. Copy **Project URL** and **anon key** from Settings → API

### 4. Run

```bash
npm run dev
```

Visit **http://localhost:3000**

---

## Deploy to Vercel

```bash
npm install -g vercel
vercel
```

Or connect your GitHub repo at [vercel.com](https://vercel.com) and set environment variables in the Vercel dashboard.

---

## Features

| Feature | Description |
|---|---|
| **Onboarding** | 4-step setup wizard with goal selection and demo data seeding |
| **Dashboard** | Command-center overview with cognitive status, tasks, finances |
| **Planner** | Task management + calendar with full CRUD |
| **Finances** | Transactions, goals, charts, category breakdown |
| **Brain** | Sleep tracking, cognitive scoring, 3 mental games |
| **AI Assistant** | GPT-4o with function calling — creates tasks, events, transactions |
| **Settings** | Profile, theme toggle, integration placeholders |
| **Pricing page** | Free vs Pro comparison |
| **Dark/Light mode** | Full theme support with CSS variables |
| **Keyboard shortcuts** | ⌘K command palette, ⌘1-5 nav, ? for help |
| **PWA** | Installable on iOS and Android |
| **Email digest** | Daily summary via Resend (optional) |

---

## Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `⌘K` | Open command palette |
| `⌘1` | Dashboard |
| `⌘2` | Planner |
| `⌘3` | Finances |
| `⌘4` | Brain |
| `⌘5` | AI Assistant |
| `?` | Show all shortcuts |
| `Esc` | Close modal/panel |

---

## PWA Installation

NeuroFlow is a Progressive Web App. To install on mobile:

**iOS Safari**: Share button → "Add to Home Screen"
**Android Chrome**: Menu → "Add to Home Screen" or "Install App"

---

## Email Digest Setup

1. Create account at [resend.com](https://resend.com)
2. Add your domain and verify
3. Set `RESEND_API_KEY` and `RESEND_FROM_EMAIL` in `.env.local`
4. Set up a cron job to POST to `/api/email` with:
   ```json
   { "userId": "user-uuid" }
   ```
   With header: `Authorization: Bearer YOUR_CRON_SECRET`

Using Supabase Edge Functions for the cron job is recommended.

---

## Cognitive Scoring

Scores are computed from real data using heuristic logic — no fake randomness:

- **Cognitive Score**: Blend of sleep quality/consistency + exercise accuracy
- **Focus Score**: Exercise accuracy × sleep quality
- **Fatigue Score**: Inverse of sleep duration + consistency variance  
- **Burnout Risk**: Multi-factor: fatigue + sleep deficit + variance

---

© 2025 NeuroFlow — Built for peak performance
