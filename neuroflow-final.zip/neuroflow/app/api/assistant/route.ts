import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import { createClient } from "@/lib/supabase/server";
import { SYSTEM_PROMPT, TOOLS, type ToolName } from "@/lib/contextSummarizer";
import { todayKey } from "@/lib/dates";

const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

// ─── Tool executor — runs DB actions server-side ──────────────────────────────
async function executeTool(name: ToolName, args: Record<string, unknown>, userId: string) {
  const supabase = createClient();

  switch (name) {
    case "create_task": {
      const { data, error } = await supabase
        .from("tasks")
        .insert({
          user_id:     userId,
          title:       args.title       as string,
          description: args.description as string | null ?? null,
          due_date:    args.due_date    as string | null ?? null,
          priority:    (args.priority   as string) || "medium",
          category:    args.category    as string | null ?? null,
          status:      "todo",
        })
        .select()
        .single();
      if (error) throw error;
      return { success: true, created: "task", data };
    }

    case "create_event": {
      const startRaw = args.start_time as string;
      const endRaw   = args.end_time   as string;
      // Ensure ISO strings
      const start = new Date(startRaw).toISOString();
      const end   = new Date(endRaw).toISOString();
      const { data, error } = await supabase
        .from("calendar_events")
        .insert({
          user_id:     userId,
          title:       args.title       as string,
          description: args.description as string | null ?? null,
          start_time:  start,
          end_time:    end,
        })
        .select()
        .single();
      if (error) throw error;
      return { success: true, created: "event", data };
    }

    case "create_transaction": {
      const { data, error } = await supabase
        .from("financial_transactions")
        .insert({
          user_id:     userId,
          type:        args.type        as string,
          amount:      args.amount      as number,
          category:    (args.category   as string).toLowerCase(),
          description: args.description as string | null ?? null,
          date:        (args.date       as string) || todayKey(),
        })
        .select()
        .single();
      if (error) throw error;
      return { success: true, created: "transaction", data };
    }

    case "list_tasks": {
      const { data } = await supabase
        .from("tasks")
        .select("title, status, priority, due_date")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })
        .limit(20);
      return { tasks: data ?? [] };
    }

    case "get_financial_summary": {
      const { data } = await supabase
        .from("financial_transactions")
        .select("type, amount")
        .eq("user_id", userId);
      const transactions = data ?? [];
      const income  = transactions.filter(t => t.type === "income").reduce((s,t)=>s+t.amount,0);
      const expense = transactions.filter(t => t.type === "expense").reduce((s,t)=>s+t.amount,0);
      return { income, expense, balance: income - expense };
    }

    default:
      return { error: "Unknown tool" };
  }
}

// ─── Main handler ─────────────────────────────────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    const { messages, contextSummary } = await req.json();

    // No API key — graceful fallback
    if (!openai) {
      return NextResponse.json({
        message: "⚠️ AI not configured. Add your `OPENAI_API_KEY` to `.env.local` to enable the assistant.\n\nAll other NeuroFlow features (tasks, finances, brain tracking) work without it.",
        fallback: true,
        actions: [],
      });
    }

    // Get authenticated user for tool execution
    const supabase = createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

    // Build system prompt with today's date + user context
    const today = new Date().toLocaleDateString("en-US", { weekday:"long", year:"numeric", month:"long", day:"numeric" });
    const systemContent = [
      SYSTEM_PROMPT,
      `\nToday is ${today}.`,
      contextSummary ? `\n--- USER APP CONTEXT ---\n${contextSummary}\n--- END CONTEXT ---` : "",
    ].join("");

    // ── First call — let model decide what to do ──
    const openaiMessages: OpenAI.Chat.ChatCompletionMessageParam[] = [
      { role: "system", content: systemContent },
      ...messages.map((m: { role: string; content: string }) => ({
        role:    m.role as "user" | "assistant",
        content: m.content,
      })),
    ];

    const firstResponse = await openai.chat.completions.create({
      model:       process.env.OPENAI_MODEL || "gpt-4o",
      messages:    openaiMessages,
      tools:       TOOLS as OpenAI.Chat.ChatCompletionTool[],
      tool_choice: "auto",
      max_tokens:  1200,
      temperature: 0.7,
    });

    const firstChoice = firstResponse.choices[0];
    const firstMsg    = firstChoice.message;

    // ── No tool calls — just return text response ──
    if (!firstMsg.tool_calls || firstMsg.tool_calls.length === 0) {
      return NextResponse.json({
        message: firstMsg.content ?? "No response.",
        actions: [],
      });
    }

    // ── Execute all tool calls ──
    const toolResults: Array<{ tool: string; result: unknown; args: unknown }> = [];
    const toolMessages: OpenAI.Chat.ChatCompletionMessageParam[] = [];

    // Add assistant message with tool calls
    toolMessages.push({ role: "assistant", content: firstMsg.content ?? null, tool_calls: firstMsg.tool_calls });

    for (const toolCall of firstMsg.tool_calls) {
      const toolName = toolCall.function.name as ToolName;
      const toolArgs = JSON.parse(toolCall.function.arguments);

      let result: unknown;
      try {
        result = await executeTool(toolName, toolArgs, user.id);
      } catch (err) {
        result = { error: String(err) };
      }

      toolResults.push({ tool: toolName, result, args: toolArgs });

      // Add tool result message
      toolMessages.push({
        role:         "tool",
        tool_call_id: toolCall.id,
        content:      JSON.stringify(result),
      });
    }

    // ── Second call — model generates final user-facing response ──
    const finalResponse = await openai.chat.completions.create({
      model:       process.env.OPENAI_MODEL || "gpt-4o",
      messages:    [...openaiMessages, ...toolMessages],
      max_tokens:  800,
      temperature: 0.7,
    });

    const finalText = finalResponse.choices[0]?.message?.content ?? "Done.";

    // Build actions summary for UI feedback
    const actions = toolResults
      .filter(r => (r.result as Record<string,unknown>)?.success)
      .map(r => ({
        type:  (r.result as Record<string,unknown>).created as string,
        title: (r.args   as Record<string,unknown>).title   as string
             || (r.args  as Record<string,unknown>).description as string
             || "Item",
      }));

    return NextResponse.json({ message: finalText, actions });

  } catch (err: unknown) {
    console.error("AI route error:", err);
    return NextResponse.json({ error: "Failed to get AI response" }, { status: 500 });
  }
}
