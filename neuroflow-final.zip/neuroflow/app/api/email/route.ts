import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

// Daily digest email via Resend
// Called by a cron job or Supabase Edge Function

export async function POST(req: NextRequest) {
  try {
    // Verify internal secret
    const authHeader = req.headers.get("authorization");
    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { userId } = await req.json();
    const supabase = createClient();

    // Fetch user data
    const [
      { data: profile },
      { data: tasks },
      { data: events },
      { data: txns },
      { data: sleepLogs },
      { data: cogStatus },
    ] = await Promise.all([
      supabase.from("profiles").select("full_name, email").eq("id", userId).single(),
      supabase.from("tasks").select("*").eq("user_id", userId).neq("status", "done").order("priority"),
      supabase.from("calendar_events").select("*").eq("user_id", userId)
        .gte("start_time", new Date().toISOString())
        .lte("start_time", new Date(Date.now() + 86400000).toISOString()),
      supabase.from("financial_transactions").select("type, amount").eq("user_id", userId),
      supabase.from("sleep_logs").select("*").eq("user_id", userId).order("date", { ascending: false }).limit(1),
      supabase.from("cognitive_daily_status").select("*").eq("user_id", userId).order("date", { ascending: false }).limit(1),
    ]);

    if (!profile?.email) return NextResponse.json({ error: "No email" }, { status: 400 });

    const name   = profile.full_name?.split(" ")[0] ?? "there";
    const income = (txns ?? []).filter(t => t.type === "income").reduce((s,t) => s + t.amount, 0);
    const expense= (txns ?? []).filter(t => t.type === "expense").reduce((s,t) => s + t.amount, 0);
    const today  = new Date().toLocaleDateString("en-US", { weekday:"long", month:"long", day:"numeric" });

    const taskList = (tasks ?? []).slice(0, 5).map(t =>
      `• [${t.priority.toUpperCase()}] ${t.title}${t.due_date ? ` — due ${t.due_date}` : ""}`
    ).join("\n");

    const eventList = (events ?? []).map(e =>
      `• ${e.title} at ${new Date(e.start_time).toLocaleTimeString("en-US", { hour:"2-digit", minute:"2-digit" })}`
    ).join("\n");

    const cogScore    = cogStatus?.[0]?.cognitive_score ?? "—";
    const sleepHours  = sleepLogs?.[0]?.hours_slept ?? "—";
    const balance     = income - expense;

    const emailHtml = buildEmailHtml({ name, today, taskList, eventList, cogScore, sleepHours, balance });

    // Send via Resend
    if (process.env.RESEND_API_KEY) {
      const { Resend } = await import("resend");
      const resend = new Resend(process.env.RESEND_API_KEY);
      await resend.emails.send({
        from:    process.env.RESEND_FROM_EMAIL ?? "digest@neuroflow.app",
        to:      profile.email,
        subject: `Your NeuroFlow digest — ${today}`,
        html:    emailHtml,
      });
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Email digest error:", err);
    return NextResponse.json({ error: "Failed" }, { status: 500 });
  }
}

function buildEmailHtml({ name, today, taskList, eventList, cogScore, sleepHours, balance }: {
  name: string; today: string; taskList: string; eventList: string;
  cogScore: number | string; sleepHours: number | string; balance: number;
}) {
  const balanceColor = balance >= 0 ? "#10b981" : "#ef4444";
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "https://neuroflow.app";

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NeuroFlow Daily Digest</title>
</head>
<body style="margin:0;padding:0;background:#09090f;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#09090f;padding:40px 20px;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;">

        <!-- Header -->
        <tr><td style="padding-bottom:32px;text-align:center;">
          <p style="margin:0 0 6px;font-size:11px;color:#444d62;text-transform:uppercase;letter-spacing:0.08em;">NeuroFlow Daily Digest</p>
          <h1 style="margin:0;font-size:24px;font-weight:700;color:#edeef5;letter-spacing:-0.02em;">
            Good morning, ${name}
          </h1>
          <p style="margin:6px 0 0;font-size:13px;color:#7e8aa0;">${today}</p>
        </td></tr>

        <!-- Metrics row -->
        <tr><td style="padding-bottom:20px;">
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td width="32%" style="background:#13141f;border:1px solid rgba(255,255,255,0.07);border-radius:12px;padding:16px;text-align:center;">
                <p style="margin:0 0 4px;font-size:10px;color:#444d62;text-transform:uppercase;letter-spacing:0.06em;">Cognitive</p>
                <p style="margin:0;font-size:24px;font-weight:700;color:#3b82f6;">${cogScore}</p>
              </td>
              <td width="4%"></td>
              <td width="32%" style="background:#13141f;border:1px solid rgba(255,255,255,0.07);border-radius:12px;padding:16px;text-align:center;">
                <p style="margin:0 0 4px;font-size:10px;color:#444d62;text-transform:uppercase;letter-spacing:0.06em;">Sleep</p>
                <p style="margin:0;font-size:24px;font-weight:700;color:#6366f1;">${sleepHours}h</p>
              </td>
              <td width="4%"></td>
              <td width="32%" style="background:#13141f;border:1px solid rgba(255,255,255,0.07);border-radius:12px;padding:16px;text-align:center;">
                <p style="margin:0 0 4px;font-size:10px;color:#444d62;text-transform:uppercase;letter-spacing:0.06em;">Balance</p>
                <p style="margin:0;font-size:24px;font-weight:700;color:${balanceColor};">$${Math.abs(balance).toLocaleString()}</p>
              </td>
            </tr>
          </table>
        </td></tr>

        ${taskList ? `
        <!-- Tasks -->
        <tr><td style="background:#13141f;border:1px solid rgba(255,255,255,0.07);border-radius:12px;padding:20px;margin-bottom:16px;">
          <p style="margin:0 0 12px;font-size:11px;color:#444d62;text-transform:uppercase;letter-spacing:0.06em;">Open Tasks</p>
          <pre style="margin:0;font-family:inherit;font-size:13px;color:#7e8aa0;white-space:pre-wrap;line-height:1.7;">${taskList}</pre>
        </td></tr>
        <tr><td style="height:12px;"></td></tr>
        ` : ""}

        ${eventList ? `
        <!-- Events -->
        <tr><td style="background:#13141f;border:1px solid rgba(255,255,255,0.07);border-radius:12px;padding:20px;margin-bottom:16px;">
          <p style="margin:0 0 12px;font-size:11px;color:#444d62;text-transform:uppercase;letter-spacing:0.06em;">Today&apos;s Events</p>
          <pre style="margin:0;font-family:inherit;font-size:13px;color:#7e8aa0;white-space:pre-wrap;line-height:1.7;">${eventList}</pre>
        </td></tr>
        <tr><td style="height:12px;"></td></tr>
        ` : ""}

        <!-- CTA -->
        <tr><td style="text-align:center;padding-top:8px;padding-bottom:32px;">
          <a href="${appUrl}/app/dashboard"
            style="display:inline-block;background:#2563eb;color:#fff;text-decoration:none;font-size:13px;font-weight:500;padding:10px 24px;border-radius:8px;">
            Open NeuroFlow →
          </a>
        </td></tr>

        <!-- Footer -->
        <tr><td style="text-align:center;border-top:1px solid rgba(255,255,255,0.06);padding-top:20px;">
          <p style="margin:0;font-size:11px;color:#444d62;">
            NeuroFlow · <a href="${appUrl}/app/settings" style="color:#444d62;">Manage preferences</a>
          </p>
        </td></tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;
}
