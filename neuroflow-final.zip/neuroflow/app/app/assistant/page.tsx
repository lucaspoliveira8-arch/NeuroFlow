"use client";
import { useEffect, useState, useRef, useCallback } from "react";
import { AIMessagesService } from "@/services/aiMessages";
import { TasksService }      from "@/services/tasks";
import { EventsService }     from "@/services/events";
import { FinancesService }   from "@/services/finances";
import { BrainService }      from "@/services/brain";
import { ProfileService }    from "@/services/profile";
import { buildContextSummary } from "@/lib/contextSummarizer";
import { MessageBubble }       from "@/components/assistant/MessageBubble";
import { SuggestionPrompts }   from "@/components/assistant/SuggestionPrompts";
import { LoadingState, Toast } from "@/components/ui/index";
import type { AIMessage } from "@/types";
import { Send, Trash2, Bot, CheckCircle2, Calendar, DollarSign } from "lucide-react";

// Action pill shown after AI creates something
interface ActionResult { type: string; title: string; }

function ActionPill({ type, title }: ActionResult) {
  const config: Record<string, { icon: React.ReactNode; label: string; color: string }> = {
    task:        { icon: <CheckCircle2 size={12}/>, label: "Task created",        color: "#10b981" },
    event:       { icon: <Calendar     size={12}/>, label: "Event scheduled",     color: "#3b82f6" },
    transaction: { icon: <DollarSign   size={12}/>, label: "Transaction logged",  color: "#7c3aed" },
  };
  const c = config[type] ?? { icon: <CheckCircle2 size={12}/>, label: "Created", color: "#10b981" };
  return (
    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium"
      style={{ background: `${c.color}15`, color: c.color, border: `1px solid ${c.color}30` }}>
      {c.icon} {c.label}: <span className="font-semibold">{title}</span>
    </div>
  );
}

export default function AssistantPage() {
  const [messages,  setMessages]  = useState<AIMessage[]>([]);
  const [input,     setInput]     = useState("");
  const [loading,   setLoading]   = useState(true);
  const [sending,   setSending]   = useState(false);
  const [ctx,       setCtx]       = useState("");
  const [lastActions, setLastActions] = useState<ActionResult[]>([]);
  const [toast,     setToast]     = useState<{ type:"success"|"error"; message:string }|null>(null);
  const bottomRef   = useRef<HTMLDivElement>(null);
  const inputRef    = useRef<HTMLTextAreaElement>(null);

  const showToast = (type: "success"|"error", msg: string) => {
    setToast({ type, message: msg }); setTimeout(() => setToast(null), 4000);
  };

  const loadContext = useCallback(async () => {
    const [msgs, profile, tasks, events, transactions, goals, sleepLogs, exercises, cogStatus] = await Promise.all([
      AIMessagesService.list(), ProfileService.get(), TasksService.list(), EventsService.list(),
      FinancesService.listTransactions(), FinancesService.listGoals(),
      BrainService.listSleepLogs(), BrainService.listExerciseResults(), BrainService.getLatestCognitiveStatus(),
    ]);
    setMessages(msgs);
    setCtx(buildContextSummary({ profile: { full_name: profile?.full_name },
      tasks, events, transactions, goals, sleepLogs, exercises, cognitiveStatus: cogStatus }));
    setLoading(false);
  }, []);

  useEffect(() => { loadContext(); }, [loadContext]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, sending]);

  // Auto-resize textarea
  function handleInputChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setInput(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px";
  }

  async function sendMessage(text: string) {
    if (!text.trim() || sending) return;
    const userText = text.trim();
    setInput("");
    setLastActions([]);
    if (inputRef.current) inputRef.current.style.height = "auto";

    const tempUser: AIMessage = {
      id: "temp-user", user_id: "", role: "user",
      message: userText, created_at: new Date().toISOString(),
    };
    setMessages(prev => [...prev, tempUser]);
    setSending(true);

    try {
      // Save user message
      const savedUser = await AIMessagesService.save("user", userText);

      // Build conversation history
      const history = [
        ...messages.map(m => ({ role: m.role, content: m.message })),
        { role: "user" as const, content: userText },
      ];

      // Call AI API (with tool execution happening server-side)
      const res  = await fetch("/api/assistant", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify({ messages: history, contextSummary: ctx }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      const replyText = data.message;
      const actions   = data.actions ?? [];

      // Save assistant reply
      const savedReply = await AIMessagesService.save("assistant", replyText);

      setMessages(prev => [
        ...prev.filter(m => m.id !== "temp-user"),
        savedUser,
        savedReply,
      ]);

      // Show action pills if something was created
      if (actions.length > 0) {
        setLastActions(actions);
        showToast("success", actions.length === 1
          ? `${actions[0].type === "task" ? "Task" : actions[0].type === "event" ? "Event" : "Transaction"} created!`
          : `${actions.length} items created`
        );
      }
    } catch (err) {
      showToast("error", "Failed to get a response. Try again.");
      setMessages(prev => prev.filter(m => m.id !== "temp-user"));
    } finally {
      setSending(false);
    }
  }

  async function clearHistory() {
    try {
      await AIMessagesService.clearHistory();
      setMessages([]); setLastActions([]);
      showToast("success", "Conversation cleared");
    } catch {
      showToast("error", "Failed to clear");
    }
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(input); }
  }

  if (loading) return <LoadingState label="Initializing assistant…" />;

  const isEmpty = messages.length === 0;

  return (
    <div className="flex flex-col animate-fade-up" style={{ height: "calc(100vh - 7rem)" }}>

      {/* Header */}
      <div className="flex items-center justify-between mb-5 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: "var(--accent-muted)", border: "1px solid var(--accent-border)" }}>
            <Bot size={16} style={{ color: "var(--accent)" }} />
          </div>
          <div>
            <h1 className="text-base font-bold" style={{ color: "var(--text-primary)" }}>AI Assistant</h1>
            <p className="text-xs" style={{ color: "var(--text-tertiary)" }}>
              Ask anything · Creates tasks, events &amp; transactions
            </p>
          </div>
        </div>
        {messages.length > 0 && (
          <button onClick={clearHistory} className="btn-ghost text-xs">
            <Trash2 size={12} /> Clear
          </button>
        )}
      </div>

      {toast && <div className="flex-shrink-0 mb-3"><Toast type={toast.type} message={toast.message} onClose={() => setToast(null)}/></div>}

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto space-y-4 pb-4">
        {isEmpty ? (
          <div className="flex flex-col items-center justify-center h-full gap-6 text-center px-4">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
              style={{ background: "var(--accent-muted)", border: "1px solid var(--accent-border)" }}>
              <Bot size={26} style={{ color: "var(--accent)" }} />
            </div>
            <div>
              <h2 className="text-lg font-bold mb-1.5" style={{ color: "var(--text-primary)" }}>
                Ready to help
              </h2>
              <p className="text-sm max-w-xs leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                Ask me anything — coding, writing, planning, or questions about your data.
                I can also <strong>create tasks, events and transactions</strong> for you.
              </p>
            </div>

            {/* Capability pills */}
            <div className="flex flex-wrap justify-center gap-2 max-w-sm">
              {[
                { icon: "✅", label: "Create tasks" },
                { icon: "📅", label: "Schedule events" },
                { icon: "💳", label: "Log transactions" },
                { icon: "🧠", label: "Analyze your data" },
                { icon: "💬", label: "Answer anything" },
                { icon: "📝", label: "Help with writing" },
              ].map(c => (
                <div key={c.label} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs"
                  style={{ background: "var(--bg-raised)", border: "1px solid var(--border)", color: "var(--text-secondary)" }}>
                  {c.icon} {c.label}
                </div>
              ))}
            </div>

            <SuggestionPrompts onSelect={sendMessage} />
          </div>
        ) : (
          <>
            {messages.map(msg => <MessageBubble key={msg.id} message={msg} />)}

            {/* Typing indicator */}
            {sending && (
              <div className="flex items-start gap-3">
                <div className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: "var(--accent-muted)", border: "1px solid var(--border-strong)" }}>
                  <Bot size={13} style={{ color: "var(--accent)" }} />
                </div>
                <div className="px-4 py-3 rounded-2xl" style={{ background: "var(--bg-raised)", border: "1px solid var(--border)" }}>
                  <div className="flex gap-1 items-center h-4">
                    {[0,150,300].map(d => (
                      <div key={d} className="w-1.5 h-1.5 rounded-full animate-bounce"
                        style={{ background: "var(--text-tertiary)", animationDelay: `${d}ms` }} />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Action pills after creation */}
            {lastActions.length > 0 && !sending && (
              <div className="flex flex-wrap gap-2 pl-10">
                {lastActions.map((a, i) => <ActionPill key={i} {...a} />)}
              </div>
            )}

            <div ref={bottomRef} />
          </>
        )}
      </div>

      {/* Input area */}
      <div className="flex-shrink-0 space-y-2 pt-2">
        {!isEmpty && !sending && messages.length > 0 && (
          <SuggestionPrompts onSelect={sendMessage} compact />
        )}

        <div className="flex items-end gap-2">
          <div
            className="flex-1 rounded-xl transition-all overflow-hidden"
            style={{ background: "var(--bg-raised)", border: "1px solid var(--border-strong)" }}
          >
            <textarea
              ref={inputRef}
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Ask anything, or say 'create a task to...' / 'schedule a meeting for...'"
              rows={1}
              className="w-full bg-transparent px-4 py-3 text-sm outline-none resize-none leading-relaxed"
              style={{ color: "var(--text-primary)", minHeight: "44px", maxHeight: "120px" }}
            />
          </div>
          <button
            onClick={() => sendMessage(input)}
            disabled={!input.trim() || sending}
            className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-all flex-shrink-0"
            style={{
              background: "var(--accent)",
              opacity: (!input.trim() || sending) ? 0.35 : 1,
              cursor: (!input.trim() || sending) ? "not-allowed" : "pointer",
            }}
          >
            <Send size={15} className="text-white" />
          </button>
        </div>
        <p className="text-center text-2xs" style={{ color: "var(--text-tertiary)" }}>
          Enter to send · Shift+Enter for new line
        </p>
      </div>
    </div>
  );
}
