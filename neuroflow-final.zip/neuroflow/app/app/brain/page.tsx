"use client";
import { useEffect, useState, useCallback } from "react";
import { BrainService } from "@/services/brain";
import { computeCognitiveMetrics } from "@/lib/cognitive";
import { SleepForm } from "@/components/brain/SleepForm";
import { SleepChart } from "@/components/brain/SleepChart";
import { CognitiveChart } from "@/components/brain/CognitiveChart";
import { MemoryGame }   from "@/components/brain/games/MemoryGame";
import { ReactionGame } from "@/components/brain/games/ReactionGame";
import { FocusGame }    from "@/components/brain/games/FocusGame";
import { Card, LoadingState, Toast, SectionHeader } from "@/components/ui/index";
import type { SleepLog, MentalExerciseResult, CognitiveDailyStatus } from "@/types";
import { Brain, Zap, Activity, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { todayKey } from "@/lib/dates";

type ActiveGame = "memory"|"reaction"|"focus"|null;

function ScoreRow({ label, value, color }: { label:string; value:number; color:string }) {
  return (
    <div className="flex items-center gap-3 py-2" style={{ borderBottom:"1px solid var(--border)" }}>
      <div className="w-28 flex-shrink-0">
        <p className="text-xs font-medium" style={{ color:"var(--text-secondary)" }}>{label}</p>
      </div>
      <div className="flex-1 score-bar">
        <div className="score-bar-fill" style={{ width:`${value}%`, background: color }}/>
      </div>
      <span className="text-sm font-bold tabular-nums w-8 text-right flex-shrink-0" style={{ color }}>{value}</span>
    </div>
  );
}

export default function BrainPage() {
  const [sleepLogs,  setSleepLogs]  = useState<SleepLog[]>([]);
  const [exercises,  setExercises]  = useState<MentalExerciseResult[]>([]);
  const [cogHistory, setCogHistory] = useState<CognitiveDailyStatus[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [activeGame, setActiveGame] = useState<ActiveGame>(null);
  const [toast,      setToast]      = useState<{ type:"success"|"error"; message:string }|null>(null);

  const showToast = (t: "success"|"error", m: string) => { setToast({ type:t, message:m }); setTimeout(() => setToast(null), 3000); };

  const load = useCallback(async () => {
    const [s, e, h] = await Promise.all([
      BrainService.listSleepLogs(), BrainService.listExerciseResults(), BrainService.listCognitiveHistory(),
    ]);
    setSleepLogs(s); setExercises(e); setCogHistory(h); setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const updateCog = useCallback(async (s: SleepLog[], e: MentalExerciseResult[]) => {
    const m = computeCognitiveMetrics(s, e);
    try {
      await BrainService.saveCognitiveStatus({ date: todayKey(), cognitive_score: m.cognitiveScore,
        focus_score: m.focusScore, fatigue_score: m.fatigueScore, burnout_risk: m.burnoutRisk, ai_summary: null });
      setCogHistory(await BrainService.listCognitiveHistory());
    } catch {}
  }, []);

  const metrics = computeCognitiveMetrics(sleepLogs, exercises);

  async function handleLogSleep(p: Omit<SleepLog,"id"|"user_id"|"created_at">) {
    try {
      const log     = await BrainService.logSleep(p);
      const updated = [log, ...sleepLogs.filter(s => s.date !== log.date)].sort((a,b) => b.date.localeCompare(a.date));
      setSleepLogs(updated);
      await updateCog(updated, exercises);
      showToast("success", "Sleep logged");
    } catch { showToast("error", "Failed to log sleep"); }
  }

  async function handleExercise(r: Omit<MentalExerciseResult,"id"|"user_id"|"created_at">) {
    try {
      const saved   = await BrainService.saveExerciseResult(r);
      const updated = [saved, ...exercises];
      setExercises(updated);
      await updateCog(sleepLogs, updated);
      showToast("success", `Done! Score: ${r.score}`);
    } catch { showToast("error", "Failed to save result"); }
    setActiveGame(null);
  }

  const avg7h = sleepLogs.slice(0,7).reduce((s,l) => s + l.hours_slept, 0) / Math.max(sleepLogs.slice(0,7).length, 1);
  const avg7q = sleepLogs.slice(0,7).reduce((s,l) => s + l.sleep_quality, 0) / Math.max(sleepLogs.slice(0,7).length, 1);

  if (loading) return <LoadingState label="Loading cognitive data…" />;

  const scoreColor = (v: number, inv = false) => {
    const e = inv ? 100 - v : v;
    return e >= 70 ? "#10b981" : e >= 45 ? "#f59e0b" : "#f43f5e";
  };

  return (
    <div className="space-y-6 animate-fade-up">
      <div>
        <h1 className="text-2xl font-bold" style={{ color:"var(--text-primary)" }}>Brain</h1>
        <p className="text-sm mt-0.5" style={{ color:"var(--text-tertiary)" }}>Cognitive performance, sleep, and mental training</p>
      </div>

      {toast && <Toast type={toast.type} message={toast.message} onClose={() => setToast(null)}/>}

      {/* Cognitive status */}
      <Card className="p-5">
        <p className="section-heading mb-4">Today&apos;s Cognitive Status</p>
        <ScoreRow label="Cognitive"  value={metrics.cognitiveScore} color={scoreColor(metrics.cognitiveScore)}/>
        <ScoreRow label="Focus"      value={metrics.focusScore}     color={scoreColor(metrics.focusScore)}/>
        <ScoreRow label="Fatigue"    value={metrics.fatigueScore}   color={scoreColor(metrics.fatigueScore, true)}/>
        <ScoreRow label="Burnout Risk" value={metrics.burnoutRisk}  color={scoreColor(metrics.burnoutRisk, true)}/>
      </Card>

      {/* Sleep row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-1">
          <SleepForm onSave={handleLogSleep}/>
        </div>
        <Card className="lg:col-span-2 p-5">
          <div className="flex items-center justify-between mb-1">
            <p className="section-heading">Sleep History</p>
            <div className="flex items-center gap-4 text-xs" style={{ color:"var(--text-tertiary)" }}>
              <span>7-day avg: <span style={{ color:"var(--text-primary)" }}>{avg7h.toFixed(1)}h</span></span>
              <span>Quality: <span style={{ color:"var(--text-primary)" }}>{avg7q.toFixed(1)}/5</span></span>
            </div>
          </div>
          <SleepChart logs={sleepLogs.slice(0,14).reverse()}/>
        </Card>
      </div>

      {/* Cognitive trend */}
      {cogHistory.length > 1 && (
        <Card className="p-5">
          <p className="section-heading mb-4">Cognitive Trend (30 days)</p>
          <CognitiveChart history={cogHistory.slice().reverse()}/>
        </Card>
      )}

      {/* Mental exercises */}
      <div>
        <SectionHeader title="Mental Exercises" description="Train focus, memory, and reaction speed"/>
        {activeGame ? (
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <p className="text-sm font-semibold" style={{ color:"var(--text-primary)" }}>
                {{ memory:"Memory Sequence", reaction:"Reaction Time", focus:"Focus Match" }[activeGame]}
              </p>
              <button onClick={() => setActiveGame(null)} className="btn-ghost text-xs">✕ Exit</button>
            </div>
            {activeGame === "memory"   && <MemoryGame   onComplete={handleExercise}/>}
            {activeGame === "reaction" && <ReactionGame onComplete={handleExercise}/>}
            {activeGame === "focus"    && <FocusGame    onComplete={handleExercise}/>}
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { id:"memory"   as ActiveGame, icon:Brain,    title:"Memory Sequence", desc:"Memorize and reproduce sequences. Boosts working memory.", color:"#7c3aed" },
              { id:"reaction" as ActiveGame, icon:Zap,      title:"Reaction Time",   desc:"Test neural processing speed. Benchmark your reflexes.",  color:"#f59e0b" },
              { id:"focus"    as ActiveGame, icon:Activity, title:"Focus Match",      desc:"Match shapes under time pressure. Trains attention.",       color:"var(--accent)" },
            ].map(game => {
              const Icon = game.icon;
              const typeKey = game.id === "memory" ? "memory_sequence" : game.id === "reaction" ? "reaction_time" : "focus_match";
              const recent  = exercises.filter(e => e.exercise_type === typeKey).slice(0,3);
              const best    = recent.length > 0 ? Math.max(...recent.map(r => r.score)) : null;
              return (
                <Card key={game.id} className="p-5 card-hover cursor-pointer group" onClick={() => setActiveGame(game.id)}>
                  <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-3"
                    style={{ background: `${game.color}18` }}>
                    <Icon size={16} style={{ color: game.color }}/>
                  </div>
                  <h4 className="text-sm font-semibold mb-1" style={{ color:"var(--text-primary)" }}>{game.title}</h4>
                  <p className="text-xs leading-relaxed mb-4" style={{ color:"var(--text-secondary)" }}>{game.desc}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs" style={{ color:"var(--text-tertiary)" }}>
                      {best !== null ? <>Best: <span style={{ color: game.color }}>{best}</span></> : "Not played"}
                    </span>
                    <span className="text-xs flex items-center gap-1 group-hover:gap-1.5 transition-all"
                      style={{ color:"var(--text-tertiary)" }}>
                      Play <ChevronRight size={11}/>
                    </span>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Recent results */}
      {exercises.length > 0 && (
        <Card className="p-5">
          <p className="section-heading mb-3">Recent Results</p>
          <div>
            {exercises.slice(0,8).map((ex, idx) => (
              <div key={ex.id} className="flex items-center gap-3 py-2.5"
                style={{ borderBottom: idx < Math.min(exercises.length,8)-1 ? "1px solid var(--border)" : "none" }}>
                <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background:"var(--accent)" }}/>
                <span className="text-xs flex-1 capitalize" style={{ color:"var(--text-secondary)" }}>
                  {ex.exercise_type.replace(/_/g," ")}
                </span>
                <span className="text-xs font-semibold" style={{ color:"var(--text-primary)" }}>Score: {ex.score}</span>
                <span className="text-xs" style={{ color:"var(--text-tertiary)" }}>{ex.accuracy}% acc</span>
                {ex.reaction_time && <span className="text-xs" style={{ color:"var(--text-tertiary)" }}>{ex.reaction_time}ms</span>}
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
