"use client";
import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { TasksService }    from "@/services/tasks";
import { FinancesService } from "@/services/finances";
import { BrainService }    from "@/services/brain";
import { EventsService }   from "@/services/events";
import { ProfileService }  from "@/services/profile";
import { computeCognitiveMetrics } from "@/lib/cognitive";
import { formatCurrency, formatDisplay, formatTime, groupByMonth, todayKey } from "@/lib/dates";
import { Card, LoadingState, EmptyState, Skeleton } from "@/components/ui/index";
import type { Task, CalendarEvent, FinancialTransaction } from "@/types";
import { Plus, Bot, Moon, DollarSign, Calendar, ArrowRight } from "lucide-react";

function ScoreRow({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs w-28 flex-shrink-0" style={{ color: "var(--text-tertiary)" }}>{label}</span>
      <div className="flex-1 score-bar">
        <div className="score-bar-fill" style={{ width: `${value}%`, background: color }} />
      </div>
      <span className="text-xs font-semibold tabular-nums w-7 text-right flex-shrink-0" style={{ color }}>{value}</span>
    </div>
  );
}

function getScoreColor(v: number, invert = false) {
  const e = invert ? 100 - v : v;
  return e >= 70 ? "#10b981" : e >= 45 ? "#f59e0b" : "#ef4444";
}

export default function DashboardPage() {
  const [loading,      setLoading]      = useState(true);
  const [profile,      setProfile]      = useState<{ full_name?: string | null } | null>(null);
  const [tasks,        setTasks]        = useState<Task[]>([]);
  const [events,       setEvents]       = useState<CalendarEvent[]>([]);
  const [transactions, setTransactions] = useState<FinancialTransaction[]>([]);
  const [metrics,      setMetrics]      = useState({ cognitiveScore:0, focusScore:0, fatigueScore:0, burnoutRisk:0 });
  const [monthly,      setMonthly]      = useState<{ month:string; income:number; expense:number }[]>([]);

  const load = useCallback(async () => {
    const [p, t, ev, tx, sleep, ex] = await Promise.all([
      ProfileService.get(), TasksService.list(), EventsService.list(),
      FinancesService.listTransactions(), BrainService.listSleepLogs(), BrainService.listExerciseResults(),
    ]);
    setProfile(p); setTasks(t); setEvents(ev); setTransactions(tx);
    setMetrics(computeCognitiveMetrics(sleep, ex));
    setMonthly(groupByMonth(tx.map(t => ({ date: t.date, amount: t.amount, type: t.type }))));
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const openTasks = tasks.filter(t => t.status !== "done");
  const done      = tasks.filter(t => t.status === "done");
  const rate      = tasks.length > 0 ? Math.round((done.length / tasks.length) * 100) : 0;
  const urgent    = openTasks.filter(t => t.priority === "urgent" || t.priority === "high").slice(0, 4);
  const upcoming  = events
    .filter(e => e.start_time > new Date().toISOString())
    .sort((a,b) => a.start_time.localeCompare(b.start_time))
    .slice(0, 4);
  const { income, expense, balance } = FinancesService.computeSummary(transactions);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const firstName = profile?.full_name?.split(" ")[0] ?? "there";

  if (loading) {
    return (
      <div className="space-y-6 animate-fade-in">
        <div className="space-y-1.5">
          <Skeleton className="h-3 w-24" />
          <Skeleton className="h-7 w-36" />
        </div>
        <Skeleton className="h-36 w-full rounded-[14px]" />
        <div className="grid grid-cols-3 gap-4">
          <Skeleton className="h-40 rounded-[14px]" />
          <Skeleton className="h-40 rounded-[14px]" />
          <Skeleton className="h-40 rounded-[14px]" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 animate-fade-up">

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs mb-0.5" style={{ color: "var(--text-tertiary)" }}>{greeting}</p>
          <h1 className="text-2xl font-bold" style={{ color: "var(--text-primary)", letterSpacing: "-0.02em" }}>
            {firstName}
          </h1>
          <p className="text-xs mt-1" style={{ color: "var(--text-tertiary)" }}>
            {new Date().toLocaleDateString("en-US", { weekday:"long", month:"long", day:"numeric" })}
          </p>
        </div>
        <Link href="/app/assistant" className="btn-primary text-xs">
          <Bot size={13} /> Ask AI
        </Link>
      </div>

      {/* Cognitive card */}
      <Card className="p-5">
        <div className="flex items-center justify-between mb-4">
          <p className="section-heading">Cognitive Status</p>
          <Link href="/app/brain" className="text-xs font-medium flex items-center gap-1"
            style={{ color: "var(--text-tertiary)" }}>
            Details <ArrowRight size={11} />
          </Link>
        </div>
        <div className="space-y-3">
          <ScoreRow label="Cognitive"   value={metrics.cognitiveScore} color={getScoreColor(metrics.cognitiveScore)} />
          <ScoreRow label="Focus"       value={metrics.focusScore}     color={getScoreColor(metrics.focusScore)} />
          <ScoreRow label="Fatigue"     value={metrics.fatigueScore}   color={getScoreColor(metrics.fatigueScore, true)} />
          <ScoreRow label="Burnout Risk"value={metrics.burnoutRisk}    color={getScoreColor(metrics.burnoutRisk, true)} />
        </div>
      </Card>

      {/* 3-col grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* Tasks */}
        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="section-heading">Tasks</p>
            <Link href="/app/planner" className="text-xs" style={{ color: "var(--text-tertiary)" }}>All →</Link>
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <span className="text-2xl font-bold tabular-nums" style={{ color: "var(--text-primary)" }}>{rate}%</span>
            <span className="text-xs" style={{ color: "var(--text-tertiary)" }}>complete · {openTasks.length} open</span>
          </div>
          <div className="score-bar mb-4">
            <div className="score-bar-fill" style={{ width:`${rate}%`, background:"var(--accent)" }} />
          </div>
          <div className="space-y-2">
            {urgent.length === 0
              ? <p className="text-xs" style={{ color:"var(--text-tertiary)" }}>No urgent tasks</p>
              : urgent.map(task => (
                <div key={task.id} className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                    style={{ background: task.priority==="urgent" ? "#ef4444" : "#f59e0b" }} />
                  <span className="text-xs truncate" style={{ color:"var(--text-secondary)" }}>{task.title}</span>
                </div>
              ))
            }
          </div>
          <Link href="/app/planner" className="btn-ghost mt-3 px-0 text-xs gap-1">
            <Plus size={11} /> Add task
          </Link>
        </Card>

        {/* Finance */}
        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="section-heading">Finances</p>
            <Link href="/app/finances" className="text-xs" style={{ color:"var(--text-tertiary)" }}>All →</Link>
          </div>
          <p className="text-xs mb-1" style={{ color:"var(--text-tertiary)" }}>Balance</p>
          <p className="text-2xl font-bold tabular-nums mb-4"
            style={{ color: balance >= 0 ? "#10b981" : "#ef4444", letterSpacing:"-0.02em" }}>
            {formatCurrency(balance)}
          </p>
          <div className="divider mb-4" />
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="text-2xs mb-0.5" style={{ color:"var(--text-tertiary)" }}>Income</p>
              <p className="text-sm font-semibold" style={{ color:"#10b981" }}>{formatCurrency(income)}</p>
            </div>
            <div>
              <p className="text-2xs mb-0.5" style={{ color:"var(--text-tertiary)" }}>Expenses</p>
              <p className="text-sm font-semibold" style={{ color:"#ef4444" }}>{formatCurrency(expense)}</p>
            </div>
          </div>
          <Link href="/app/finances" className="btn-ghost mt-3 px-0 text-xs gap-1">
            <Plus size={11} /> Add transaction
          </Link>
        </Card>

        {/* Upcoming */}
        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="section-heading">Upcoming</p>
            <Link href="/app/planner" className="text-xs" style={{ color:"var(--text-tertiary)" }}>All →</Link>
          </div>
          {upcoming.length === 0
            ? <EmptyState icon={<Calendar size={20}/>} title="No events"
                action={<Link href="/app/planner" className="text-xs" style={{ color:"var(--accent)" }}>Add event →</Link>}/>
            : (
              <div className="space-y-3">
                {upcoming.map(ev => (
                  <div key={ev.id} className="flex items-start gap-2.5">
                    <div className="w-0.5 self-stretch min-h-[2rem] rounded-full flex-shrink-0 mt-0.5"
                      style={{ background:"var(--accent-border)" }} />
                    <div className="min-w-0">
                      <p className="text-xs font-medium truncate" style={{ color:"var(--text-primary)" }}>{ev.title}</p>
                      <p className="text-2xs mt-0.5" style={{ color:"var(--text-tertiary)" }}>
                        {formatDisplay(ev.start_time,"MMM d")} · {formatTime(ev.start_time)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )
          }
        </Card>
      </div>

      {/* Spending chart */}
      {monthly.length > 1 && (
        <Card className="p-5">
          <div className="flex items-center justify-between mb-5">
            <p className="section-heading">Monthly Trend</p>
            <div className="flex items-center gap-4 text-2xs" style={{ color:"var(--text-tertiary)" }}>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 rounded inline-block" style={{ background:"#10b981" }}/> Income
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 rounded inline-block" style={{ background:"#ef4444" }}/> Expenses
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={150}>
            <AreaChart data={monthly} margin={{ top:0, right:0, left:-24, bottom:0 }}>
              <defs>
                <linearGradient id="gi2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#10b981" stopOpacity={0.14}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="ge2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#ef4444" stopOpacity={0.10}/>
                  <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="month" tick={{ fill:"var(--text-tertiary)", fontSize:10 }} axisLine={false} tickLine={false}/>
              <YAxis tick={{ fill:"var(--text-tertiary)", fontSize:10 }} axisLine={false} tickLine={false}/>
              <Tooltip contentStyle={{ background:"var(--bg-overlay)", border:"1px solid var(--border)", borderRadius:8, fontSize:12, color:"var(--text-primary)" }}
                formatter={(v:number) => formatCurrency(v)}/>
              <Area type="monotone" dataKey="income"  stroke="#10b981" strokeWidth={1.5} fill="url(#gi2)" name="Income"/>
              <Area type="monotone" dataKey="expense" stroke="#ef4444" strokeWidth={1.5} fill="url(#ge2)" name="Expenses"/>
            </AreaChart>
          </ResponsiveContainer>
        </Card>
      )}

      {/* Quick actions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { href:"/app/planner",   icon:Plus,       label:"New Task",       color:"var(--accent)" },
          { href:"/app/assistant", icon:Bot,        label:"Ask AI",         color:"#7c3aed" },
          { href:"/app/brain",     icon:Moon,       label:"Log Sleep",      color:"#6366f1" },
          { href:"/app/finances",  icon:DollarSign, label:"Add Transaction",color:"#10b981" },
        ].map(a => {
          const Icon = a.icon;
          return (
            <Link key={a.href} href={a.href} className="card card-interactive p-4 flex flex-col items-center gap-2 text-center">
              <Icon size={17} style={{ color: a.color }} />
              <span className="text-xs font-medium" style={{ color:"var(--text-secondary)" }}>{a.label}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
