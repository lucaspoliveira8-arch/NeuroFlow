"use client";
import { useEffect, useState, useCallback } from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { FinancesService } from "@/services/finances";
import { TransactionModal } from "@/components/finances/TransactionModal";
import { GoalModal } from "@/components/finances/GoalModal";
import { Card, LoadingState, EmptyState, Toast, SectionHeader } from "@/components/ui/index";
import { formatCurrency, formatDisplay, groupByMonth } from "@/lib/dates";
import type { FinancialTransaction, FinancialGoal } from "@/types";
import { Plus, TrendingUp, TrendingDown, Wallet, Target, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";

const PIE_COLORS = ["#3b82f6","#7c3aed","#ec4899","#f59e0b","#10b981","#f43f5e","#06b6d4"];

export default function FinancesPage() {
  const [transactions, setTransactions] = useState<FinancialTransaction[]>([]);
  const [goals,        setGoals]        = useState<FinancialGoal[]>([]);
  const [loading,      setLoading]      = useState(true);
  const [txModal,      setTxModal]      = useState(false);
  const [goalModal,    setGoalModal]    = useState(false);
  const [toast,        setToast]        = useState<{ type:"success"|"error"; message:string }|null>(null);

  const showToast = (type: "success"|"error", msg: string) => {
    setToast({ type, message: msg }); setTimeout(() => setToast(null), 3000);
  };

  const load = useCallback(async () => {
    const [tx, g] = await Promise.all([FinancesService.listTransactions(), FinancesService.listGoals()]);
    setTransactions(tx); setGoals(g); setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const { income, expense, balance } = FinancesService.computeSummary(transactions);
  const monthly = groupByMonth(transactions.map(t => ({ date: t.date, amount: t.amount, type: t.type })));

  const pieData = Object.entries(
    transactions.filter(t => t.type === "expense")
      .reduce((acc, t) => { acc[t.category] = (acc[t.category]||0) + t.amount; return acc; }, {} as Record<string,number>)
  ).sort((a,b) => b[1]-a[1]).slice(0,7).map(([name,value]) => ({ name, value }));

  async function handleAddTx(p: Omit<FinancialTransaction,"id"|"user_id"|"created_at">) {
    try { const tx = await FinancesService.createTransaction(p); setTransactions(prev => [tx,...prev]); setTxModal(false); showToast("success","Transaction added"); }
    catch { showToast("error","Failed to add"); }
  }

  async function handleDelTx(id: string) {
    try { await FinancesService.deleteTransaction(id); setTransactions(prev => prev.filter(t => t.id !== id)); showToast("success","Deleted"); }
    catch { showToast("error","Failed to delete"); }
  }

  async function handleAddGoal(p: Omit<FinancialGoal,"id"|"user_id"|"created_at">) {
    try { const g = await FinancesService.createGoal(p); setGoals(prev => [g,...prev]); setGoalModal(false); showToast("success","Goal created"); }
    catch { showToast("error","Failed to create goal"); }
  }

  async function handleDelGoal(id: string) {
    try { await FinancesService.deleteGoal(id); setGoals(prev => prev.filter(g => g.id !== id)); showToast("success","Goal deleted"); }
    catch { showToast("error","Failed to delete goal"); }
  }

  if (loading) return <LoadingState label="Loading finances…" />;

  return (
    <div className="space-y-6 animate-fade-up">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: "var(--text-primary)" }}>Finances</h1>
          <p className="text-sm mt-0.5" style={{ color: "var(--text-tertiary)" }}>Track income, expenses, and savings goals</p>
        </div>
        <button onClick={() => setTxModal(true)} className="btn-primary">
          <Plus size={14} /> Transaction
        </button>
      </div>

      {toast && <Toast type={toast.type} message={toast.message} onClose={() => setToast(null)} />}

      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {[
          { label: "Balance",  value: formatCurrency(balance),  color: balance >= 0 ? "#10b981" : "#f43f5e", icon: Wallet },
          { label: "Income",   value: formatCurrency(income),   color: "#10b981", icon: TrendingUp },
          { label: "Expenses", value: formatCurrency(expense),  color: "#f43f5e", icon: TrendingDown },
        ].map(({ label, value, color, icon: Icon }) => (
          <Card key={label} className="p-5">
            <div className="flex items-center gap-2 mb-2">
              <Icon size={14} style={{ color }} />
              <p className="section-heading">{label}</p>
            </div>
            <p className="text-2xl font-bold tabular-nums" style={{ color }}>{value}</p>
            <p className="text-xs mt-1" style={{ color: "var(--text-tertiary)" }}>
              {transactions.filter(t => t.type === (label === "Income" ? "income" : "expense")).length} transactions
            </p>
          </Card>
        ))}
      </div>

      {/* Charts */}
      {monthly.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card className="lg:col-span-2 p-5">
            <p className="section-heading mb-4">Monthly Trend</p>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={monthly} margin={{ top:0, right:0, left:-24, bottom:0 }}>
                <defs>
                  <linearGradient id="gi" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#10b981" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="ge" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#f43f5e" stopOpacity={0.12}/>
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" tick={{ fill:"var(--text-tertiary)", fontSize:10 }} axisLine={false} tickLine={false}/>
                <YAxis tick={{ fill:"var(--text-tertiary)", fontSize:10 }} axisLine={false} tickLine={false}/>
                <Tooltip contentStyle={{ background:"var(--bg-overlay)", border:"1px solid var(--border)", borderRadius:8, fontSize:12, color:"var(--text-primary)" }} formatter={(v:number) => formatCurrency(v)}/>
                <Area type="monotone" dataKey="income"  stroke="#10b981" strokeWidth={1.5} fill="url(#gi)" name="Income"/>
                <Area type="monotone" dataKey="expense" stroke="#f43f5e" strokeWidth={1.5} fill="url(#ge)" name="Expenses"/>
              </AreaChart>
            </ResponsiveContainer>
          </Card>

          {pieData.length > 0 && (
            <Card className="p-5">
              <p className="section-heading mb-4">By Category</p>
              <ResponsiveContainer width="100%" height={120}>
                <PieChart>
                  <Pie data={pieData} cx="50%" cy="50%" innerRadius={30} outerRadius={55} dataKey="value" strokeWidth={0}>
                    {pieData.map((_,i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} fillOpacity={0.85}/>)}
                  </Pie>
                  <Tooltip contentStyle={{ background:"var(--bg-overlay)", border:"1px solid var(--border)", borderRadius:8, fontSize:11, color:"var(--text-primary)" }} formatter={(v:number) => formatCurrency(v)}/>
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 mt-3">
                {pieData.slice(0,4).map((d,i) => (
                  <div key={d.name} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }}/>
                      <span className="capitalize" style={{ color:"var(--text-secondary)" }}>{d.name}</span>
                    </div>
                    <span style={{ color:"var(--text-primary)" }}>{formatCurrency(d.value)}</span>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      )}

      {/* Goals */}
      <div>
        <SectionHeader title="Financial Goals" description="Track your savings targets"
          action={<button onClick={() => setGoalModal(true)} className="btn-secondary text-xs"><Plus size={12}/> Goal</button>}/>
        {goals.length === 0
          ? <EmptyState icon={<Target size={24}/>} title="No goals yet" description="Set a savings goal to track your progress"
              action={<button onClick={() => setGoalModal(true)} className="btn-primary text-xs">+ Add Goal</button>}/>
          : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {goals.map(goal => {
                const pct = Math.min(100, Math.round((goal.current_amount / goal.target_amount) * 100));
                const barColor = pct >= 100 ? "#10b981" : pct >= 60 ? "var(--accent)" : "#7c3aed";
                return (
                  <Card key={goal.id} className="p-4 card-hover group">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold truncate" style={{ color:"var(--text-primary)" }}>{goal.title}</p>
                        {goal.deadline && <p className="text-xs mt-0.5" style={{ color:"var(--text-tertiary)" }}>Target: {formatDisplay(goal.deadline)}</p>}
                      </div>
                      <button onClick={() => handleDelGoal(goal.id)}
                        className="btn-ghost p-1 opacity-0 group-hover:opacity-100 transition-opacity ml-1">
                        <Trash2 size={12}/>
                      </button>
                    </div>
                    <div className="flex items-baseline justify-between mb-2">
                      <span className="text-xl font-bold tabular-nums" style={{ color: barColor }}>{pct}%</span>
                      <span className="text-xs" style={{ color:"var(--text-tertiary)" }}>
                        {formatCurrency(goal.current_amount)} / {formatCurrency(goal.target_amount)}
                      </span>
                    </div>
                    <div className="score-bar">
                      <div className="score-bar-fill" style={{ width:`${pct}%`, background: barColor }}/>
                    </div>
                    <p className="text-xs mt-2" style={{ color:"var(--text-tertiary)" }}>
                      {formatCurrency(goal.target_amount - goal.current_amount)} remaining
                    </p>
                  </Card>
                );
              })}
            </div>
          )
        }
      </div>

      {/* Transactions */}
      <div>
        <SectionHeader title="Transactions" description={`${transactions.length} total`}/>
        {transactions.length === 0
          ? <EmptyState icon={<Wallet size={24}/>} title="No transactions yet" description="Add your first income or expense"
              action={<button onClick={() => setTxModal(true)} className="btn-primary text-xs">+ Add Transaction</button>}/>
          : (
            <Card className="overflow-hidden">
              {transactions.slice(0,25).map((tx, idx) => (
                <div key={tx.id}
                  className="flex items-center gap-3 px-5 py-3.5 group transition-colors"
                  style={{ borderBottom: idx < transactions.slice(0,25).length - 1 ? "1px solid var(--border)" : "none" }}
                  onMouseEnter={e => (e.currentTarget as HTMLDivElement).style.background = "var(--bg-subtle)"}
                  onMouseLeave={e => (e.currentTarget as HTMLDivElement).style.background = "transparent"}
                >
                  <div className="w-2 h-2 rounded-full flex-shrink-0"
                    style={{ background: tx.type === "income" ? "#10b981" : "#f43f5e" }}/>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate" style={{ color:"var(--text-primary)" }}>
                      {tx.description || tx.category}
                    </p>
                    <p className="text-xs capitalize mt-0.5" style={{ color:"var(--text-tertiary)" }}>
                      {tx.category} · {formatDisplay(tx.date)}
                    </p>
                  </div>
                  <p className="text-sm font-semibold tabular-nums flex-shrink-0"
                    style={{ color: tx.type === "income" ? "#10b981" : "#f43f5e" }}>
                    {tx.type === "income" ? "+" : "−"}{formatCurrency(tx.amount)}
                  </p>
                  <button onClick={() => handleDelTx(tx.id)}
                    className="btn-ghost p-1.5 opacity-0 group-hover:opacity-100 transition-opacity ml-1">
                    <Trash2 size={12}/>
                  </button>
                </div>
              ))}
            </Card>
          )
        }
      </div>

      {txModal   && <TransactionModal onSave={handleAddTx}   onClose={() => setTxModal(false)}/>}
      {goalModal && <GoalModal        onSave={handleAddGoal} onClose={() => setGoalModal(false)}/>}
    </div>
  );
}
