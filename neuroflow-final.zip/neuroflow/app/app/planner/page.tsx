"use client";
import { useEffect, useState, useCallback } from "react";
import { TasksService }  from "@/services/tasks";
import { EventsService } from "@/services/events";
import { TaskList }     from "@/components/planner/TaskList";
import { TaskModal }    from "@/components/planner/TaskModal";
import { CalendarView } from "@/components/planner/CalendarView";
import { EventModal }   from "@/components/planner/EventModal";
import { LoadingState, Toast } from "@/components/ui/index";
import type { Task, CalendarEvent } from "@/types";
import { LayoutList, CalendarDays } from "lucide-react";
import { cn } from "@/lib/utils";

type View = "tasks"|"calendar";

export default function PlannerPage() {
  const [view,       setView]       = useState<View>("tasks");
  const [tasks,      setTasks]      = useState<Task[]>([]);
  const [events,     setEvents]     = useState<CalendarEvent[]>([]);
  const [loading,    setLoading]    = useState(true);
  const [taskModal,  setTaskModal]  = useState<{ open:boolean; task?:Task }>({ open:false });
  const [eventModal, setEventModal] = useState<{ open:boolean; event?:CalendarEvent }>({ open:false });
  const [toast,      setToast]      = useState<{ type:"success"|"error"; message:string }|null>(null);

  const showToast = (type: "success"|"error", message: string) => {
    setToast({ type, message }); setTimeout(() => setToast(null), 3000);
  };

  const load = useCallback(async () => {
    const [t, e] = await Promise.all([TasksService.list(), EventsService.list()]);
    setTasks(t); setEvents(e); setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handleSaveTask(p: Omit<Task,"id"|"user_id"|"created_at">) {
    try {
      if (taskModal.task) {
        const u = await TasksService.update(taskModal.task.id, p);
        setTasks(prev => prev.map(t => t.id === u.id ? u : t));
        showToast("success","Task updated");
      } else {
        const c = await TasksService.create(p);
        setTasks(prev => [c, ...prev]);
        showToast("success","Task created");
      }
      setTaskModal({ open:false });
    } catch { showToast("error","Failed to save task"); }
  }

  async function handleDelTask(id: string) {
    try { await TasksService.delete(id); setTasks(prev => prev.filter(t => t.id !== id)); showToast("success","Task deleted"); }
    catch { showToast("error","Failed to delete"); }
  }

  async function handleToggle(task: Task) {
    try { const u = await TasksService.toggleStatus(task); setTasks(prev => prev.map(t => t.id === u.id ? u : t)); }
    catch { showToast("error","Failed to update"); }
  }

  async function handleSaveEvent(p: Omit<CalendarEvent,"id"|"user_id"|"created_at">) {
    try {
      if (eventModal.event) {
        const u = await EventsService.update(eventModal.event.id, p);
        setEvents(prev => prev.map(e => e.id === u.id ? u : e));
        showToast("success","Event updated");
      } else {
        const c = await EventsService.create(p);
        setEvents(prev => [...prev, c]);
        showToast("success","Event created");
      }
      setEventModal({ open:false });
    } catch { showToast("error","Failed to save event"); }
  }

  async function handleDelEvent(id: string) {
    try { await EventsService.delete(id); setEvents(prev => prev.filter(e => e.id !== id)); showToast("success","Event deleted"); }
    catch { showToast("error","Failed to delete"); }
  }

  return (
    <div className="space-y-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold" style={{ color:"var(--text-primary)" }}>Planner</h1>
          <p className="text-sm mt-0.5" style={{ color:"var(--text-tertiary)" }}>Tasks, events, and your execution workspace</p>
        </div>
        <div className="flex items-center gap-2">
          {/* View toggle */}
          <div className="flex rounded-lg p-0.5" style={{ background:"var(--bg-subtle)", border:"1px solid var(--border-strong)" }}>
            {([{v:"tasks" as View, icon:LayoutList, l:"Tasks"},{v:"calendar" as View, icon:CalendarDays, l:"Calendar"}]).map(({v,icon:Icon,l}) => (
              <button key={v} onClick={() => setView(v)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all"
                style={{
                  background: view === v ? "var(--bg-raised)" : "transparent",
                  color:      view === v ? "var(--text-primary)" : "var(--text-tertiary)",
                  boxShadow:  view === v ? "var(--shadow-card)" : "none",
                }}>
                <Icon size={13}/> {l}
              </button>
            ))}
          </div>
          <button
            onClick={() => view === "tasks" ? setTaskModal({ open:true }) : setEventModal({ open:true })}
            className="btn-primary">
            + {view === "tasks" ? "Task" : "Event"}
          </button>
        </div>
      </div>

      {toast && <Toast type={toast.type} message={toast.message} onClose={() => setToast(null)}/>}

      {loading ? <LoadingState/> : view === "tasks" ? (
        <TaskList tasks={tasks} onEdit={t => setTaskModal({ open:true, task:t })}
          onDelete={handleDelTask} onToggle={handleToggle} onAdd={() => setTaskModal({ open:true })}/>
      ) : (
        <CalendarView tasks={tasks} events={events}
          onEditEvent={e => setEventModal({ open:true, event:e })}
          onDeleteEvent={handleDelEvent} onAddEvent={() => setEventModal({ open:true })}/>
      )}

      {taskModal.open  && <TaskModal  task={taskModal.task}   onSave={handleSaveTask}  onClose={() => setTaskModal({ open:false })}/>}
      {eventModal.open && <EventModal event={eventModal.event} onSave={handleSaveEvent} onClose={() => setEventModal({ open:false })}/>}
    </div>
  );
}
