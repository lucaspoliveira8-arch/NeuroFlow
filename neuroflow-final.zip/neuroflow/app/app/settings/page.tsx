"use client";
import { useEffect, useState, useCallback } from "react";
import { ProfileService } from "@/services/profile";
import { createClient } from "@/lib/supabase/client";
import { Card, Spinner, Toast, SectionHeader } from "@/components/ui/index";
import { useTheme } from "@/components/ui/ThemeProvider";
import { User, Sun, Moon, Calendar, Watch, CreditCard, Bell } from "lucide-react";

export default function SettingsPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<{ type: "success"|"error"; message: string } | null>(null);
  const { theme, toggle } = useTheme();

  const load = useCallback(async () => {
    const { data: { user } } = await createClient().auth.getUser();
    setEmail(user?.email ?? "");
    const p = await ProfileService.get();
    setName(p?.full_name ?? "");
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault(); setSaving(true);
    try {
      await ProfileService.upsert({ full_name: name.trim() });
      setToast({ type: "success", message: "Profile saved" });
    } catch {
      setToast({ type: "error", message: "Failed to save" });
    } finally {
      setSaving(false);
      setTimeout(() => setToast(null), 3000);
    }
  }

  const integrations = [
    { icon: Calendar, name: "Google Calendar", desc: "Sync events automatically" },
    { icon: Watch,    name: "Wearables",        desc: "Import health data from Apple Watch or Garmin" },
    { icon: CreditCard, name: "Bank Feeds",     desc: "Auto-import transactions from your bank" },
    { icon: Bell,     name: "Notifications",    desc: "Smart reminders for tasks and cognitive alerts" },
  ];

  return (
    <div className="space-y-6 max-w-xl animate-fade-up">
      <div>
        <h1 className="text-2xl font-bold" style={{ color: "var(--text-primary)" }}>Settings</h1>
        <p className="text-sm mt-0.5" style={{ color: "var(--text-tertiary)" }}>Manage your profile and preferences</p>
      </div>

      {toast && <Toast type={toast.type} message={toast.message} onClose={() => setToast(null)} />}

      {/* Profile */}
      <Card className="p-6">
        <SectionHeader title="Profile" description="Your personal information" />
        {loading ? (
          <div className="flex items-center gap-2 py-4">
            <Spinner size={14} /> <span className="text-sm" style={{ color: "var(--text-tertiary)" }}>Loading…</span>
          </div>
        ) : (
          <form onSubmit={handleSave} className="space-y-4">
            {/* Avatar row */}
            <div className="flex items-center gap-3 mb-5">
              <div className="w-11 h-11 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0"
                style={{ background: "var(--accent-muted)", color: "var(--accent)" }}>
                {(name || email).slice(0, 2).toUpperCase()}
              </div>
              <div>
                <p className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>{name || "No name"}</p>
                <p className="text-xs" style={{ color: "var(--text-tertiary)" }}>{email}</p>
              </div>
            </div>
            <div>
              <label className="label">Full Name</label>
              <input value={name} onChange={e => setName(e.target.value)} className="input" placeholder="Your full name" />
            </div>
            <div>
              <label className="label">Email</label>
              <input value={email} disabled className="input opacity-50 cursor-not-allowed" />
              <p className="text-2xs mt-1" style={{ color: "var(--text-tertiary)" }}>Email cannot be changed here</p>
            </div>
            <button type="submit" disabled={saving} className="btn-primary">
              {saving && <Spinner size={12} className="text-white" />}
              {saving ? "Saving…" : "Save changes"}
            </button>
          </form>
        )}
      </Card>

      {/* Appearance */}
      <Card className="p-6">
        <SectionHeader title="Appearance" />
        <div className="flex items-center justify-between py-2">
          <div>
            <p className="text-sm font-medium" style={{ color: "var(--text-primary)" }}>Theme</p>
            <p className="text-xs mt-0.5" style={{ color: "var(--text-tertiary)" }}>
              {theme === "dark" ? "Dark mode active" : "Light mode active"}
            </p>
          </div>
          <button
            onClick={toggle}
            className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all"
            style={{ background: "var(--bg-subtle)", border: "1px solid var(--border-strong)", color: "var(--text-primary)" }}
          >
            {theme === "dark" ? <><Sun size={14} /> Switch to Light</> : <><Moon size={14} /> Switch to Dark</>}
          </button>
        </div>
      </Card>

      {/* Integrations */}
      <Card className="p-6">
        <SectionHeader title="Integrations" description="Connect external services" />
        <div className="space-y-2">
          {integrations.map(({ icon: Icon, name, desc }) => (
            <div key={name}
              className="flex items-center gap-3 p-3 rounded-[10px] opacity-60 cursor-not-allowed"
              style={{ border: "1px solid var(--border)", background: "var(--bg-subtle)" }}
            >
              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{ background: "var(--bg-overlay)" }}>
                <Icon size={15} style={{ color: "var(--text-secondary)" }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium" style={{ color: "var(--text-primary)" }}>{name}</p>
                <p className="text-xs" style={{ color: "var(--text-tertiary)" }}>{desc}</p>
              </div>
              <span className="tag tag-gray text-2xs">Coming soon</span>
            </div>
          ))}
        </div>
      </Card>

      <p className="text-center text-2xs pb-4" style={{ color: "var(--text-tertiary)" }}>
        NeuroFlow v1.0 — Built for peak performance
      </p>
    </div>
  );
}
