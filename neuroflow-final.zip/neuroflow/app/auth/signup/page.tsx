"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { BrainMark } from "@/components/ui/BrainMark";
import { Spinner } from "@/components/ui/index";
import { Eye, EyeOff } from "lucide-react";

export default function SignupPage() {
  const router = useRouter();
  const [name,     setName]     = useState("");
  const [email,    setEmail]    = useState("");
  const [password, setPassword] = useState("");
  const [show,     setShow]     = useState(false);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setError(null);
    const { error } = await createClient().auth.signUp({
      email, password,
      options: { data: { full_name: name } },
    });
    if (error) { setError(error.message); setLoading(false); return; }
    // → Onboarding first
    router.push("/onboarding");
    router.refresh();
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{ background: "var(--bg-base)" }}>
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-2 mb-5" style={{ color: "var(--accent)" }}>
            <BrainMark size={26} />
            <span className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>NeuroFlow</span>
          </Link>
          <h1 className="text-xl font-bold mb-1" style={{ color: "var(--text-primary)", letterSpacing:"-0.02em" }}>
            Create your account
          </h1>
          <p className="text-sm" style={{ color: "var(--text-secondary)" }}>Free to start. No credit card required.</p>
        </div>
        <div className="card p-6">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Full Name</label>
              <input value={name} onChange={e => setName(e.target.value)} className="input" placeholder="Alex Morgan" required />
            </div>
            <div>
              <label className="label">Email</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="input" placeholder="you@example.com" required />
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <input type={show?"text":"password"} value={password} onChange={e => setPassword(e.target.value)}
                  className="input pr-10" placeholder="At least 8 characters" minLength={8} required />
                <button type="button" onClick={() => setShow(!show)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 btn-ghost p-0" style={{ color:"var(--text-tertiary)" }}>
                  {show ? <EyeOff size={14}/> : <Eye size={14}/>}
                </button>
              </div>
            </div>
            {error && (
              <p className="text-xs px-3 py-2 rounded-lg"
                style={{ background:"rgba(239,68,68,0.08)", color:"#ef4444", border:"1px solid rgba(239,68,68,0.18)" }}>
                {error}
              </p>
            )}
            <button type="submit" disabled={loading} className="btn-primary w-full justify-center py-2.5">
              {loading && <Spinner size={13} className="text-white" />}
              {loading ? "Creating account…" : "Create account"}
            </button>
          </form>
        </div>
        <p className="text-center text-xs mt-5" style={{ color:"var(--text-tertiary)" }}>
          Already have an account?{" "}
          <Link href="/auth/login" className="font-medium hover:underline" style={{ color:"var(--accent)" }}>Sign in</Link>
        </p>
      </div>
    </div>
  );
}
