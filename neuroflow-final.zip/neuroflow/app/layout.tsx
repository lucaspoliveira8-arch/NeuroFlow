import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/components/ui/ThemeProvider";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "NeuroFlow — Think Clearer. Plan Better. Live Smarter.",
    template: "%s — NeuroFlow",
  },
  description: "NeuroFlow is a premium AI-powered personal operating system combining tasks, finances, cognitive health, sleep, and AI assistance.",
  keywords: ["productivity", "AI", "cognitive performance", "personal finance", "sleep tracking", "task manager"],
  authors: [{ name: "NeuroFlow" }],
  creator: "NeuroFlow",
  openGraph: {
    type: "website",
    title: "NeuroFlow — Think Clearer. Plan Better. Live Smarter.",
    description: "Your AI-powered cognitive operating system.",
    siteName: "NeuroFlow",
  },
  twitter: {
    card: "summary_large_image",
    title: "NeuroFlow",
    description: "Think Clearer. Plan Better. Live Smarter.",
  },
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "NeuroFlow",
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)",  color: "#09090f" },
    { media: "(prefers-color-scheme: light)", color: "#f7f8fc" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="apple-touch-icon" sizes="192x192" href="/icon-192.png" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="mobile-web-app-capable" content="yes" />
      </head>
      <body className={`${inter.variable} font-sans antialiased`}>
        <ThemeProvider>
          {children}
        </ThemeProvider>
        <script dangerouslySetInnerHTML={{ __html: `
          if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
              navigator.serviceWorker.register('/sw.js').catch(() => {});
            });
          }
        `}} />
      </body>
    </html>
  );
}
