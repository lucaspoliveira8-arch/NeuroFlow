"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { BrainMark } from "@/components/ui/BrainMark";
import { Spinner } from "@/components/ui/index";
import { TasksService } from "@/services/tasks";
import { BrainService } from "@/services/brain";
import { FinancesService } from "@/services/finances";
import { ProfileService } from "@/services/profile";
import { createClient } from "@/lib/supabase/client";
import { todayKey } from "@/lib/dates";
import { CheckCircle2, Brain, DollarSign, Moon, Zap, ArrowRight, Target } from "lucide-react";
import { cn } from "@/lib/utils";

const FOCUS_OPTIONS = [
  { id: "productivity", icon: Zap,       label: "Productivity",    desc: "Get more done, reduce overwhelm" },
  { id: "finance",      icon: DollarSign, label: "Financial health", desc: "Track money, hit savings goals" },
  { id: "cognitive",    icon: Brain,      label: "Cognitive performance", desc: "Sharpen focus, avoid burnout" },
  { id: "sleep",        icon: Moon,       label: "Better sleep",    desc: "Improve rest, boost recovery" },
];

const STEPS = ["Welcome", "Your goals", "First task", "You're set"];

export default function OnboardingPage() {
  const router = useRouter();
  const [step,    setStep]    = useState(0);
  const [name,    setName]    = useState("");
  const [goals,   setGoals]   = useState<string[]>([]);
  const [task,    setTask]    = useState("");
  const [saving,  setSaving]  = useState(false);

  function toggleGoal(id: string) {
    setGoals(prev => prev.includes(id) ? prev.filter(g => g !== id) : [...prev, id]);
  }

  async function finish() {
    setSaving(true);
    try {
      // Save name
      if (name.trim()) await ProfileService.upsert({ full_name: name.trim() });

      // Save first task
      if (task.trim()) {
        await TasksService.create({
          title: task.trim(), description: null,
          due_date: todayKey(), priority: "high",
          category: "Personal", status: "todo",
        });
      }

      // Seed demo data if they have no data yet
      await seedDemoData(goals);

      // Mark onboarding done
      const supabase = createClient();
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from("profiles")
          .update({ onboarding_done: true } as never)
          .eq("id", user.id);
      }

      router.push("/app/dashboard");
    } catch (e) {
      console.error(e);
      router.push("/app/dashboard");
    }
  }

  async function seedDemoData(selectedGoals: string[]) {
    const today = todayKey();
    const tasks = [
      { title: "Review weekly priorities", priority: "high" as const, category: "Work", status: "todo" as const, due_date: today, description: null },
      { title: "30-minute workout", priority: "medium" as const, category: "Health", status: "todo" as const, due_date: today, description: null },
      { title: "Read for 20 minutes", priority: "low" as const, category: "Personal", status: "done" as const, due_date: today, description: null },
    ];
    for (const t of tasks) await TasksService.create(t).catch(() => {});

    if (selectedGoals.includes("finance")) {
      await FinancesService.createTransaction({ type:"income",  amount:4500, category:"salary",    description:"Monthly salary",  date: today }).catch(()=>{});
      await FinancesService.createTransaction({ type:"expense", amount:1200, category:"housing",   description:"Rent",            date: today }).catch(()=>{});
      await FinancesService.createTransaction({ type:"expense", amount:180,  category:"food",      description:"Groceries",       date: today }).catch(()=>{});
      await FinancesService.createGoal({ title:"Emergency Fund", target_amount:10000, current_amount:2400, deadline:null }).catch(()=>{});
    }

    if (selectedGoals.includes("sleep") || selectedGoals.includes("cognitive")) {
      const dates = Array.from({ length: 5 }, (_, i) => {
        const d = new Date(); d.setDate(d.getDate() - i - 1);
        return d.toISOString().slice(0,10);
      });
      for (const date of dates) {
        await BrainService.logSleep({
          date, hours_slept: 6.5 + Math.random(), sleep_quality: (Math.floor(Math.random()*2)+3) as 3|4|5, notes: null,
        }).catch(()=>{});
      }
    }
  }

  const canProceed = [
    true,
    goals.length > 0,
    true,
    true,
  ][step];

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12"
      style={{ background: "var(--bg-base)" }}>

      <div className="w-full max-w-lg">
        {/* Brand */}
        <div className="flex items-center justify-center gap-2 mb-10" style={{ color: "var(--accent)" }}>
          <BrainMark size={24} />
          <span className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>NeuroFlow</span>
        </div>

        {/* Progress bar */}
        <div className="flex items-center gap-2 mb-8">
          {STEPS.map((s, i) => (
            <div key={s} className="flex items-center gap-2 flex-1">
              <div className="flex items-center gap-1.5 flex-shrink-0">
                <div className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-all"
                  style={{
                    background: i < step ? "#10b981" : i === step ? "var(--accent)" : "var(--bg-subtle)",
                    color: i <= step ? "#fff" : "var(--text-tertiary)",
                    border: `1px solid ${i < step ? "#10b981" : i === step ? "var(--accent)" : "var(--border-strong)"}`,
                  }}>
                  {i < step ? <CheckCircle2 size={13} /> : i + 1}
                </div>
              </div>
              {i < STEPS.length - 1 && (
                <div className="flex-1 h-px" style={{ background: i < step ? "#10b981" : "var(--border-strong)" }} />
              )}
            </div>
          ))}
        </div>

        {/* Card */}
        <div className="card p-8" style={{ boxShadow: "var(--shadow-modal)" }}>

          {/* Step 0 — Welcome */}
          {step === 0 && (
            <div className="space-y-5 animate-fade-up">
              <div>
                <h1 className="text-2xl font-bold mb-2" style={{ color: "var(--text-primary)", letterSpacing: "-0.02em" }}>
                  Welcome to NeuroFlow
                </h1>
                <p className="text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                  Let&apos;s take 60 seconds to set up your personal operating system.
                </p>
              </div>
              <div>
                <label className="label">What should we call you?</label>
                <input
                  value={name} onChange={e => setName(e.target.value)}
                  className="input text-base" placeholder="Your first name"
                  autoFocus
                  onKeyDown={e => e.key === "Enter" && setStep(1)}
                />
              </div>
            </div>
          )}

          {/* Step 1 — Goals */}
          {step === 1 && (
            <div className="space-y-5 animate-fade-up">
              <div>
                <h2 className="text-xl font-bold mb-1" style={{ color: "var(--text-primary)", letterSpacing: "-0.02em" }}>
                  What do you want to improve?
                </h2>
                <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
                  Select all that apply. We&apos;ll set up your dashboard accordingly.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {FOCUS_OPTIONS.map(({ id, icon: Icon, label, desc }) => {
                  const sel = goals.includes(id);
                  return (
                    <button key={id} onClick={() => toggleGoal(id)}
                      className="card card-interactive p-4 text-left transition-all"
                      style={{
                        borderColor: sel ? "var(--accent)" : "var(--border)",
                        background: sel ? "var(--accent-muted)" : "var(--bg-raised)",
                      }}>
                      <div className="flex items-start justify-between mb-2">
                        <Icon size={16} style={{ color: sel ? "var(--accent)" : "var(--text-tertiary)" }} />
                        {sel && <CheckCircle2 size={14} style={{ color: "var(--accent)" }} />}
                      </div>
                      <p className="text-sm font-semibold mb-0.5" style={{ color: "var(--text-primary)" }}>{label}</p>
                      <p className="text-xs leading-snug" style={{ color: "var(--text-tertiary)" }}>{desc}</p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Step 2 — First task */}
          {step === 2 && (
            <div className="space-y-5 animate-fade-up">
              <div>
                <h2 className="text-xl font-bold mb-1" style={{ color: "var(--text-primary)", letterSpacing: "-0.02em" }}>
                  What&apos;s the most important thing you need to do today?
                </h2>
                <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
                  Add your first task. You can always skip this.
                </p>
              </div>
              <div>
                <label className="label">Task title</label>
                <input
                  value={task} onChange={e => setTask(e.target.value)}
                  className="input" placeholder="e.g. Finish the quarterly report"
                  autoFocus
                  onKeyDown={e => e.key === "Enter" && setStep(3)}
                />
              </div>
              <button onClick={() => setStep(3)} className="btn-ghost text-xs px-0">
                Skip for now →
              </button>
            </div>
          )}

          {/* Step 3 — Ready */}
          {step === 3 && (
            <div className="space-y-5 animate-fade-up text-center py-4">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-2"
                style={{ background: "rgba(16,185,129,0.10)", border: "1px solid rgba(16,185,129,0.20)" }}>
                <CheckCircle2 size={28} style={{ color: "#10b981" }} />
              </div>
              <div>
                <h2 className="text-xl font-bold mb-2" style={{ color: "var(--text-primary)", letterSpacing: "-0.02em" }}>
                  {name ? `You're all set, ${name}!` : "You're all set!"}
                </h2>
                <p className="text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                  Your NeuroFlow system is ready. We&apos;ve pre-loaded some sample data so your
                  dashboard looks alive from day one.
                </p>
              </div>
              <div className="grid grid-cols-3 gap-2 text-xs" style={{ color: "var(--text-tertiary)" }}>
                {[
                  { icon: "✅", label: "Tasks ready" },
                  { icon: "🧠", label: "Cognitive tracking" },
                  { icon: "🤖", label: "AI assistant on" },
                ].map(i => (
                  <div key={i.label} className="card p-3 flex flex-col items-center gap-1">
                    <span className="text-lg">{i.icon}</span>
                    <span>{i.label}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CTA */}
          <div className="flex gap-3 mt-8">
            {step > 0 && step < 3 && (
              <button onClick={() => setStep(s => s - 1)} className="btn-secondary flex-shrink-0">Back</button>
            )}
            {step < 3 ? (
              <button
                onClick={() => setStep(s => s + 1)}
                disabled={!canProceed}
                className="btn-primary flex-1 justify-center">
                Continue <ArrowRight size={14} />
              </button>
            ) : (
              <button onClick={finish} disabled={saving} className="btn-primary flex-1 justify-center py-3 text-base">
                {saving ? <><Spinner size={15} className="text-white" /> Setting up…</> : "Launch NeuroFlow →"}
              </button>
            )}
          </div>
        </div>

        {/* Step indicator text */}
        <p className="text-center text-xs mt-4" style={{ color: "var(--text-tertiary)" }}>
          Step {step + 1} of {STEPS.length}
        </p>
      </div>
    </div>
  );
}
