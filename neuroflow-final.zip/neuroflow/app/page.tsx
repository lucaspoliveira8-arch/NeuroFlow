"use client";
import Link from "next/link";
import { BrainMark } from "@/components/ui/BrainMark";
import { useTheme } from "@/components/ui/ThemeProvider";
import { ArrowRight, Brain, DollarSign, Moon, Bot, Zap, BarChart3, Sun, CheckCircle2 } from "lucide-react";

const FEATURES = [
  { icon: Brain,     label: "Cognitive Engine",  desc: "Real-time focus, fatigue, and burnout risk scoring." },
  { icon: Zap,       label: "Smart Planner",     desc: "Tasks, calendar events, and priorities in one workspace." },
  { icon: DollarSign,label: "Financial Clarity", desc: "Income, expenses, and savings goals — beautifully organized." },
  { icon: Moon,      label: "Sleep Intelligence",desc: "Log and analyze your sleep quality and recovery trends." },
  { icon: Bot,       label: "AI Assistant",      desc: "Creates tasks, schedules events, and answers anything." },
  { icon: BarChart3, label: "Deep Analytics",    desc: "30-day trends across every domain of your life." },
];

const PROOF = [
  "No credit card required",
  "Free to start",
  "Your data stays private",
];

export default function LandingPage() {
  const { theme, toggle } = useTheme();

  return (
    <div className="min-h-screen" style={{ background: "var(--bg-base)", color: "var(--text-primary)" }}>

      {/* ── Nav ─────────────────────────────────────────────── */}
      <nav className="sticky top-0 z-30 h-14"
        style={{ background: "var(--bg-raised)", borderBottom: "1px solid var(--border)", backdropFilter: "blur(12px)" }}>
        <div className="max-w-5xl mx-auto h-full flex items-center justify-between px-5">
          <div className="flex items-center gap-2.5" style={{ color: "var(--accent)" }}>
            <BrainMark size={22} />
            <span className="text-sm font-bold tracking-tight" style={{ color: "var(--text-primary)" }}>NeuroFlow</span>
          </div>
          <div className="flex items-center gap-1">
            <button onClick={toggle} className="btn-ghost p-2" title="Toggle theme">
              {theme === "dark" ? <Sun size={14} /> : <Moon size={14} />}
            </button>
            <Link href="/pricing" className="btn-ghost text-xs">Pricing</Link>
            <Link href="/auth/login" className="btn-ghost text-xs">Sign in</Link>
            <Link href="/auth/signup" className="btn-primary text-xs py-1.5">Get started free</Link>
          </div>
        </div>
      </nav>

      {/* ── Hero ─────────────────────────────────────────────── */}
      <section className="max-w-4xl mx-auto px-5 pt-20 pb-16 text-center">
        {/* Badge */}
        <div
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-8"
          style={{ background: "var(--accent-muted)", color: "var(--accent)", border: "1px solid var(--accent-border)" }}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-current" style={{ animation: "pulse 2s ease infinite" }} />
          Cognitive Operating System
        </div>

        {/* Headline */}
        <h1
          className="text-5xl sm:text-[58px] font-bold tracking-tight leading-[1.06] mb-5"
          style={{ color: "var(--text-primary)", letterSpacing: "-0.03em" }}
        >
          Think Clearer.<br />
          <span style={{ color: "var(--accent)" }}>Plan Better.</span><br />
          Live Smarter.
        </h1>

        <p className="text-base max-w-md mx-auto mb-8 leading-relaxed" style={{ color: "var(--text-secondary)" }}>
          NeuroFlow combines tasks, finances, cognitive health, sleep tracking, and AI assistance
          into one calm, intelligent interface.
        </p>

        {/* CTA */}
        <div className="flex items-center justify-center gap-3 flex-wrap mb-5">
          <Link href="/auth/signup" className="btn-primary px-6 py-2.5 text-sm">
            Start for free <ArrowRight size={14} />
          </Link>
          <Link href="/auth/login" className="btn-secondary px-6 py-2.5 text-sm">
            Sign in
          </Link>
        </div>

        {/* Social proof */}
        <div className="flex items-center justify-center gap-4 flex-wrap">
          {PROOF.map(p => (
            <div key={p} className="flex items-center gap-1.5 text-xs" style={{ color: "var(--text-tertiary)" }}>
              <CheckCircle2 size={12} style={{ color: "#10b981" }} /> {p}
            </div>
          ))}
        </div>

        {/* App preview */}
        <div
          className="mt-14 rounded-2xl overflow-hidden mx-auto max-w-3xl animate-fade-up delay-200"
          style={{ border: "1px solid var(--border)", boxShadow: "var(--shadow-modal)", background: "var(--bg-raised)" }}
        >
          {/* Window chrome */}
          <div className="flex items-center gap-1.5 px-4 py-3" style={{ borderBottom: "1px solid var(--border)", background: "var(--bg-subtle)" }}>
            {["#ef4444","#f59e0b","#10b981"].map(c => (
              <div key={c} className="w-3 h-3 rounded-full" style={{ background: c, opacity: 0.7 }} />
            ))}
            <span className="ml-2 text-xs font-mono" style={{ color: "var(--text-tertiary)" }}>neuroflow.app</span>
          </div>
          {/* Dashboard preview */}
          <div className="p-5">
            <div className="grid grid-cols-3 gap-3 mb-3">
              {[
                { l: "Cognitive Score", v: "84", c: "#10b981" },
                { l: "Focus",           v: "76", c: "var(--accent)" },
                { l: "Burnout Risk",    v: "18%", c: "#f59e0b" },
              ].map(m => (
                <div key={m.l} className="card p-4 text-center">
                  <div className="text-2xl font-bold tabular-nums mb-1" style={{ color: m.c }}>{m.v}</div>
                  <div className="text-xs" style={{ color: "var(--text-tertiary)" }}>{m.l}</div>
                </div>
              ))}
            </div>
            <div className="card p-4">
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-xs font-medium" style={{ color: "var(--text-secondary)" }}>Today&apos;s tasks</span>
                <span className="tag tag-green">4 / 6 done</span>
              </div>
              <div className="score-bar">
                <div className="score-bar-fill" style={{ width: "68%", background: "var(--accent)" }} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── Features ─────────────────────────────────────────── */}
      <section className="max-w-5xl mx-auto px-5 py-16">
        <div className="text-center mb-10">
          <h2 className="text-2xl font-bold mb-2" style={{ color: "var(--text-primary)", letterSpacing: "-0.02em" }}>
            One system. Every domain.
          </h2>
          <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
            All six pillars of peak performance, in one clean interface.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {FEATURES.map(({ icon: Icon, label, desc }) => (
            <div key={label} className="card card-interactive p-5 group">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center mb-4"
                style={{ background: "var(--accent-muted)" }}>
                <Icon size={15} style={{ color: "var(--accent)" }} />
              </div>
              <h3 className="text-sm font-semibold mb-1" style={{ color: "var(--text-primary)" }}>{label}</h3>
              <p className="text-xs leading-relaxed" style={{ color: "var(--text-secondary)" }}>{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── CTA ──────────────────────────────────────────────── */}
      <section className="max-w-lg mx-auto px-5 py-16 text-center">
        <div className="card p-10">
          <div style={{ color: "var(--accent)", display: "inline-block", marginBottom: "16px" }}>
            <BrainMark size={36} />
          </div>
          <h2 className="text-xl font-bold mb-2" style={{ color: "var(--text-primary)", letterSpacing: "-0.02em" }}>
            Ready to operate at your peak?
          </h2>
          <p className="text-sm mb-7" style={{ color: "var(--text-secondary)" }}>
            Join NeuroFlow and start building a smarter life system today. Free to start.
          </p>
          <Link href="/auth/signup" className="btn-primary px-8 py-2.5 text-sm inline-flex mx-auto">
            Create free account <ArrowRight size={14} />
          </Link>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────────────────── */}
      <footer className="text-center py-6 text-xs" style={{ borderTop: "1px solid var(--border)", color: "var(--text-tertiary)" }}>
        © {new Date().getFullYear()} NeuroFlow · Built for peak performance
      </footer>
    </div>
  );
}
