"use client";
import Link from "next/link";
import { BrainMark } from "@/components/ui/BrainMark";
import { useTheme } from "@/components/ui/ThemeProvider";
import { CheckCircle2, Sun, Moon, ArrowRight, Zap } from "lucide-react";

const FREE_FEATURES = [
  "Unlimited tasks & events",
  "Financial tracking (50 transactions/mo)",
  "Sleep logging",
  "3 mental exercises",
  "Cognitive scoring",
  "AI Assistant (20 messages/day)",
  "Dark & light mode",
];

const PRO_FEATURES = [
  "Everything in Free",
  "Unlimited AI messages",
  "Daily email digest",
  "Advanced analytics & trends",
  "Google Calendar sync",
  "Wearable data import",
  "Bank feed integration",
  "Priority support",
  "Early access to new features",
];

export default function PricingPage() {
  const { theme, toggle } = useTheme();

  return (
    <div className="min-h-screen" style={{ background: "var(--bg-base)", color: "var(--text-primary)" }}>

      {/* Nav */}
      <nav className="sticky top-0 z-30 h-14"
        style={{ background: "var(--bg-raised)", borderBottom: "1px solid var(--border)" }}>
        <div className="max-w-5xl mx-auto h-full flex items-center justify-between px-5">
          <Link href="/" className="flex items-center gap-2" style={{ color: "var(--accent)" }}>
            <BrainMark size={20} />
            <span className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>NeuroFlow</span>
          </Link>
          <div className="flex items-center gap-1">
            <button onClick={toggle} className="btn-ghost p-2">
              {theme === "dark" ? <Sun size={14} /> : <Moon size={14} />}
            </button>
            <Link href="/auth/login" className="btn-ghost text-xs">Sign in</Link>
            <Link href="/auth/signup" className="btn-primary text-xs py-1.5">Get started</Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-3xl mx-auto px-5 pt-16 pb-12 text-center">
        <h1 className="text-4xl font-bold mb-3" style={{ letterSpacing: "-0.03em", color: "var(--text-primary)" }}>
          Simple, honest pricing
        </h1>
        <p className="text-base" style={{ color: "var(--text-secondary)" }}>
          Start free. Upgrade when you&apos;re ready. No tricks.
        </p>
      </section>

      {/* Plans */}
      <section className="max-w-3xl mx-auto px-5 pb-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

          {/* Free */}
          <div className="card p-7 flex flex-col">
            <div className="mb-6">
              <p className="text-sm font-semibold mb-1" style={{ color: "var(--text-secondary)" }}>Free</p>
              <div className="flex items-baseline gap-1 mb-2">
                <span className="text-4xl font-bold" style={{ color: "var(--text-primary)", letterSpacing: "-0.03em" }}>$0</span>
                <span className="text-sm" style={{ color: "var(--text-tertiary)" }}>/forever</span>
              </div>
              <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
                Everything you need to start operating smarter.
              </p>
            </div>
            <ul className="space-y-3 flex-1 mb-8">
              {FREE_FEATURES.map(f => (
                <li key={f} className="flex items-start gap-2.5 text-sm" style={{ color: "var(--text-secondary)" }}>
                  <CheckCircle2 size={15} className="flex-shrink-0 mt-0.5" style={{ color: "#10b981" }} />
                  {f}
                </li>
              ))}
            </ul>
            <Link href="/auth/signup" className="btn-secondary w-full justify-center py-2.5 text-sm">
              Get started free
            </Link>
          </div>

          {/* Pro */}
          <div className="card p-7 flex flex-col relative overflow-hidden"
            style={{ borderColor: "var(--accent-border)", background: "var(--bg-overlay)" }}>
            {/* Coming soon banner */}
            <div className="absolute top-4 right-4">
              <span className="tag tag-violet flex items-center gap-1">
                <Zap size={10} /> Coming soon
              </span>
            </div>

            <div className="mb-6">
              <p className="text-sm font-semibold mb-1" style={{ color: "var(--accent)" }}>Pro</p>
              <div className="flex items-baseline gap-1 mb-2">
                <span className="text-4xl font-bold" style={{ color: "var(--text-primary)", letterSpacing: "-0.03em" }}>$12</span>
                <span className="text-sm" style={{ color: "var(--text-tertiary)" }}>/month</span>
              </div>
              <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
                For serious performers who want the full system.
              </p>
            </div>
            <ul className="space-y-3 flex-1 mb-8">
              {PRO_FEATURES.map(f => (
                <li key={f} className="flex items-start gap-2.5 text-sm" style={{ color: "var(--text-secondary)" }}>
                  <CheckCircle2 size={15} className="flex-shrink-0 mt-0.5" style={{ color: "var(--accent)" }} />
                  {f}
                </li>
              ))}
            </ul>
            <button disabled className="btn-primary w-full justify-center py-2.5 text-sm opacity-60 cursor-not-allowed">
              Notify me when available
            </button>
          </div>
        </div>

        {/* FAQ */}
        <div className="mt-16">
          <h2 className="text-xl font-bold mb-8 text-center" style={{ color: "var(--text-primary)", letterSpacing: "-0.02em" }}>
            Frequently asked questions
          </h2>
          <div className="space-y-4 max-w-xl mx-auto">
            {[
              { q: "Is the free plan really free?", a: "Yes, forever. No trials, no credit card needed. We plan to keep a generous free tier permanently." },
              { q: "What happens to my data if I cancel?", a: "Your data is yours. You can export everything at any time from Settings. We never delete it without 30 days notice." },
              { q: "Do I need an OpenAI key?", a: "For the AI assistant, yes. You bring your own key and it stays in your environment — we never store it." },
              { q: "When is Pro launching?", a: "We're working on it. Sign up free and you'll be the first to know when Pro is available." },
            ].map(({ q, a }) => (
              <div key={q} className="card p-5">
                <p className="text-sm font-semibold mb-2" style={{ color: "var(--text-primary)" }}>{q}</p>
                <p className="text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>{a}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Final CTA */}
        <div className="card p-10 mt-12 text-center">
          <h2 className="text-xl font-bold mb-2" style={{ color: "var(--text-primary)", letterSpacing: "-0.02em" }}>
            Start for free today
          </h2>
          <p className="text-sm mb-6" style={{ color: "var(--text-secondary)" }}>
            No credit card. No commitment. Cancel anytime.
          </p>
          <Link href="/auth/signup" className="btn-primary px-8 py-2.5 inline-flex">
            Create free account <ArrowRight size={14} />
          </Link>
        </div>
      </section>
    </div>
  );
}
