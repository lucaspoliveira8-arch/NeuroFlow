"use client";
import type { AIMessage } from "@/types";
import { Bot, User } from "lucide-react";
import { formatTime } from "@/lib/dates";
import { cn } from "@/lib/utils";

function renderMarkdown(text: string): string {
  return text
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/^# (.+)$/gm, '<h2>$1</h2>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/^- (.+)$/gm, '<li>$1</li>')
    .replace(/(<li>[\s\S]*?<\/li>)/g, '<ul>$1</ul>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/^(?!<[hul])(.+)$/gm, '<p>$1</p>');
}

export function MessageBubble({ message }: { message: AIMessage }) {
  const isUser = message.role === "user";
  const isTemp = message.id === "temp-user";

  return (
    <div className={cn("flex items-start gap-3 animate-fade-up", isUser && "flex-row-reverse")}>
      {/* Avatar */}
      <div
        className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
        style={{
          background: isUser ? "var(--bg-subtle)" : "var(--accent-muted)",
          border: "1px solid var(--border-strong)",
        }}
      >
        {isUser
          ? <User size={13} style={{ color: "var(--text-tertiary)" }} />
          : <Bot  size={13} style={{ color: "var(--accent)" }} />
        }
      </div>

      {/* Bubble */}
      <div
        className="max-w-[80%] rounded-2xl px-4 py-3"
        style={{
          background: isUser ? "var(--accent-muted)" : "var(--bg-raised)",
          border: `1px solid ${isUser ? "var(--accent-border)" : "var(--border)"}`,
          borderRadius: isUser ? "16px 4px 16px 16px" : "4px 16px 16px 16px",
        }}
      >
        {isUser
          ? <p className="text-sm leading-relaxed" style={{ color: "var(--text-primary)" }}>{message.message}</p>
          : <div className="prose-ai" dangerouslySetInnerHTML={{ __html: renderMarkdown(message.message) }} />
        }
        <p className="text-2xs mt-2" style={{ color: "var(--text-tertiary)", textAlign: isUser ? "right" : "left" }}>
          {isTemp ? "Sending…" : formatTime(message.created_at)}
        </p>
      </div>
    </div>
  );
}
