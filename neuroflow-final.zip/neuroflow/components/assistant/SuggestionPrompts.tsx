"use client";

const GROUPS = [
  {
    label: "Actions",
    prompts: [
      "Create a task to review my quarterly goals",
      "Schedule a meeting tomorrow at 10am for 1 hour",
      "Log a $50 expense for food today",
      "Add a task: workout at the gym, high priority",
    ],
  },
  {
    label: "My data",
    prompts: [
      "How are my tasks looking this week?",
      "Give me a summary of my financial health",
      "Am I at risk of burnout based on my data?",
      "How has my sleep been affecting my performance?",
    ],
  },
  {
    label: "General",
    prompts: [
      "Help me write a professional email",
      "Explain how compound interest works",
      "Give me 5 tips to improve my focus",
      "What's the Pomodoro technique?",
    ],
  },
  {
    label: "Planning",
    prompts: [
      "Build me a focused plan for today",
      "What are my top 3 priorities right now?",
      "Help me break down a big project into tasks",
    ],
  },
];

interface Props { onSelect: (p: string) => void; compact?: boolean; }

export function SuggestionPrompts({ onSelect, compact = false }: Props) {
  if (compact) {
    const flat = GROUPS.flatMap(g => g.prompts).slice(0, 5);
    return (
      <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
        {flat.map(p => (
          <button key={p} onClick={() => onSelect(p)}
            className="flex-shrink-0 text-xs px-3 py-1.5 rounded-full whitespace-nowrap transition-all"
            style={{ background:"var(--bg-subtle)", border:"1px solid var(--border-strong)", color:"var(--text-secondary)" }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--accent)";
              (e.currentTarget as HTMLButtonElement).style.color = "var(--accent)";
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--border-strong)";
              (e.currentTarget as HTMLButtonElement).style.color = "var(--text-secondary)";
            }}>
            {p.length > 40 ? p.slice(0,40) + "…" : p}
          </button>
        ))}
      </div>
    );
  }

  return (
    <div className="w-full max-w-lg space-y-5">
      {GROUPS.map(g => (
        <div key={g.label}>
          <p className="section-heading mb-2">{g.label}</p>
          <div className="grid grid-cols-1 gap-1.5">
            {g.prompts.map(p => (
              <button key={p} onClick={() => onSelect(p)}
                className="text-sm text-left px-4 py-2.5 rounded-[10px] transition-all"
                style={{ background:"var(--bg-raised)", border:"1px solid var(--border)", color:"var(--text-secondary)" }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--accent-border)";
                  (e.currentTarget as HTMLButtonElement).style.color = "var(--text-primary)";
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--border)";
                  (e.currentTarget as HTMLButtonElement).style.color = "var(--text-secondary)";
                }}>
                {p}
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
