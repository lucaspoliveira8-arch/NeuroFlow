"use client";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import type { CognitiveDailyStatus } from "@/types";
import { format, parseISO } from "date-fns";

export function CognitiveChart({ history }: { history: CognitiveDailyStatus[] }) {
  const data = history.map(h => ({
    date:      format(parseISO(h.date), "MMM d"),
    cognitive: h.cognitive_score,
    focus:     h.focus_score,
    fatigue:   h.fatigue_score,
  }));

  return (
    <ResponsiveContainer width="100%" height={180}>
      <LineChart data={data} margin={{ top:0, right:0, left:-24, bottom:0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false}/>
        <XAxis dataKey="date" tick={{ fill:"var(--text-tertiary)", fontSize:10 }} axisLine={false} tickLine={false}/>
        <YAxis domain={[0,100]} tick={{ fill:"var(--text-tertiary)", fontSize:10 }} axisLine={false} tickLine={false}/>
        <Tooltip contentStyle={{ background:"var(--bg-overlay)", border:"1px solid var(--border)", borderRadius:8, fontSize:11, color:"var(--text-primary)" }}/>
        <Line type="monotone" dataKey="cognitive" stroke="var(--accent)" strokeWidth={1.5} dot={false} name="Cognitive"/>
        <Line type="monotone" dataKey="focus"     stroke="#10b981" strokeWidth={1.5} dot={false} name="Focus"/>
        <Line type="monotone" dataKey="fatigue"   stroke="#f59e0b" strokeWidth={1.5} dot={false} name="Fatigue" strokeDasharray="4 2"/>
      </LineChart>
    </ResponsiveContainer>
  );
}
