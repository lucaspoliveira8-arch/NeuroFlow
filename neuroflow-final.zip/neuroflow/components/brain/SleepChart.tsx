"use client";
import { ComposedChart, Bar, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import type { SleepLog } from "@/types";
import { format, parseISO } from "date-fns";

export function SleepChart({ logs }: { logs: SleepLog[] }) {
  if (logs.length === 0) return (
    <div className="flex items-center justify-center h-40 text-xs" style={{ color:"var(--text-tertiary)" }}>
      No sleep data yet — log your first night above
    </div>
  );

  const data = logs.map(l => ({
    date:    format(parseISO(l.date), "MMM d"),
    hours:   l.hours_slept,
    quality: l.sleep_quality,
  }));

  return (
    <ResponsiveContainer width="100%" height={180}>
      <ComposedChart data={data} margin={{ top:0, right:0, left:-24, bottom:0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false}/>
        <XAxis dataKey="date" tick={{ fill:"var(--text-tertiary)", fontSize:10 }} axisLine={false} tickLine={false}/>
        <YAxis yAxisId="h" domain={[0,12]} tick={{ fill:"var(--text-tertiary)", fontSize:10 }} axisLine={false} tickLine={false}/>
        <YAxis yAxisId="q" orientation="right" domain={[0,5]} tick={{ fill:"var(--text-tertiary)", fontSize:10 }} axisLine={false} tickLine={false}/>
        <Tooltip contentStyle={{ background:"var(--bg-overlay)", border:"1px solid var(--border)", borderRadius:8, fontSize:11, color:"var(--text-primary)" }}
          formatter={(v:number, n:string) => [n==="hours"?`${v}h`:`${v}/5`, n==="hours"?"Hours":"Quality"]}/>
        <Bar yAxisId="h" dataKey="hours" fill="var(--accent)" fillOpacity={0.5} radius={[3,3,0,0]} name="hours"/>
        <Line yAxisId="q" type="monotone" dataKey="quality" stroke="#7c3aed" strokeWidth={2} dot={{ fill:"#7c3aed", r:2.5 }} name="quality"/>
      </ComposedChart>
    </ResponsiveContainer>
  );
}
