"use client";
import { useState } from "react";
import type { SleepLog, SleepQuality } from "@/types";
import { Spinner } from "@/components/ui/index";
import { todayKey } from "@/lib/dates";
import { cn } from "@/lib/utils";

interface Props { onSave: (p: Omit<SleepLog,"id"|"user_id"|"created_at">) => Promise<void>; }

const Q_LABELS: Record<SleepQuality, string> = { 1:"Poor", 2:"Fair", 3:"Okay", 4:"Good", 5:"Great" };

export function SleepForm({ onSave }: Props) {
  const [date,    setDate]    = useState(todayKey());
  const [hours,   setHours]   = useState("7");
  const [quality, setQuality] = useState<SleepQuality>(3);
  const [notes,   setNotes]   = useState("");
  const [saving,  setSaving]  = useState(false);
  const [error,   setError]   = useState<string|null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const h = parseFloat(hours);
    if (!h || h < 0 || h > 24) { setError("Enter valid hours (0–24)"); return; }
    setSaving(true); setError(null);
    try { await onSave({ date, hours_slept: h, sleep_quality: quality, notes: notes||null }); setNotes(""); }
    catch { setError("Failed to log sleep"); }
    finally { setSaving(false); }
  }

  return (
    <div className="card p-5 h-full">
      <p className="section-heading mb-4">Log Sleep</p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="label">Date</label>
          <input type="date" value={date} onChange={e => setDate(e.target.value)} className="input" />
        </div>
        <div>
          <label className="label">Hours Slept</label>
          <input type="number" min="0" max="24" step="0.5" value={hours}
            onChange={e => setHours(e.target.value)} className="input" placeholder="7.5" />
        </div>
        <div>
          <label className="label">
            Quality — <span style={{ color: "var(--accent)" }}>{Q_LABELS[quality]}</span>
          </label>
          <div className="flex gap-1.5">
            {([1,2,3,4,5] as SleepQuality[]).map(q => (
              <button key={q} type="button" onClick={() => setQuality(q)}
                className="flex-1 py-2 rounded-lg text-xs font-semibold transition-all"
                style={{
                  background: quality === q ? "var(--accent-muted)" : "var(--bg-subtle)",
                  color: quality === q ? "var(--accent)" : "var(--text-tertiary)",
                  border: `1px solid ${quality === q ? "var(--accent-border)" : "var(--border)"}`,
                }}>
                {q}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="label">Notes</label>
          <textarea value={notes} onChange={e => setNotes(e.target.value)} className="input" rows={2} placeholder="How did you feel…" />
        </div>
        {error && <p className="text-xs" style={{ color: "#f43f5e" }}>{error}</p>}
        <button type="submit" disabled={saving} className="btn-primary w-full justify-center">
          {saving && <Spinner size={12} className="text-white" />}
          {saving ? "Logging…" : "Log Sleep"}
        </button>
      </form>
    </div>
  );
}
