"use client";
import { useState, useEffect, useRef, useCallback } from "react";
import type { MentalExerciseResult } from "@/types";
import { cn } from "@/lib/utils";

interface Props {
  onComplete: (result: Omit<MentalExerciseResult, "id" | "user_id" | "created_at">) => void;
}

const SHAPES = ["●", "■", "▲", "◆", "★"];
const COLORS_CLASSES = [
  "text-blue-400",
  "text-violet-400",
  "text-emerald-400",
  "text-rose-400",
  "text-yellow-400",
];
const TOTAL_ROUNDS = 12;
const ROUND_MS = 2500;

function generateCard() {
  return {
    shape: SHAPES[Math.floor(Math.random() * SHAPES.length)],
    color: Math.floor(Math.random() * COLORS_CLASSES.length),
  };
}

type GamePhase = "idle" | "playing" | "done";

export function FocusGame({ onComplete }: Props) {
  const [phase, setPhase] = useState<GamePhase>("idle");
  const [round, setRound] = useState(0);
  const [target, setTarget] = useState(generateCard());
  const [options, setOptions] = useState<typeof target[]>([]);
  const [correct, setCorrect] = useState(0);
  const [wrong, setWrong] = useState(0);
  const [flash, setFlash] = useState<"correct" | "wrong" | null>(null);
  const [timeLeft, setTimeLeft] = useState(ROUND_MS);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const roundRef = useRef(0);

  const endGame = useCallback((c: number) => {
    if (timerRef.current) clearInterval(timerRef.current);
    setPhase("done");
    const accuracy = Math.round((c / TOTAL_ROUNDS) * 100);
    const score = c * 10 - wrong * 3;
    onComplete({ exercise_type: "focus_match", score: Math.max(0, score), accuracy, reaction_time: null });
  }, [wrong, onComplete]);

  function makeRound(r: number) {
    const t = generateCard();
    setTarget(t);
    setTimeLeft(ROUND_MS);

    // One correct option, 3 distractors
    const opts = [{ ...t }];
    while (opts.length < 4) {
      const d = generateCard();
      if (d.shape !== t.shape || d.color !== t.color) opts.push(d);
    }
    // Shuffle
    opts.sort(() => Math.random() - 0.5);
    setOptions(opts);
  }

  function startGame() {
    setRound(0);
    setCorrect(0);
    setWrong(0);
    setPhase("playing");
    roundRef.current = 0;
    makeRound(0);
  }

  // Countdown timer per round
  useEffect(() => {
    if (phase !== "playing") return;
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 100) {
          // Timeout = wrong
          setWrong(w => w + 1);
          setFlash("wrong");
          setTimeout(() => setFlash(null), 300);
          const nextRound = roundRef.current + 1;
          roundRef.current = nextRound;
          if (nextRound >= TOTAL_ROUNDS) {
            endGame(correct);
            return ROUND_MS;
          }
          setRound(nextRound);
          makeRound(nextRound);
          return ROUND_MS;
        }
        return prev - 100;
      });
    }, 100);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [phase, round]); // eslint-disable-line

  function handleChoice(opt: typeof target) {
    if (phase !== "playing") return;
    if (opt.shape === target.shape && opt.color === target.color) {
      setCorrect(c => c + 1);
      setFlash("correct");
    } else {
      setWrong(w => w + 1);
      setFlash("wrong");
    }
    setTimeout(() => setFlash(null), 250);
    const nextRound = roundRef.current + 1;
    roundRef.current = nextRound;
    if (nextRound >= TOTAL_ROUNDS) {
      endGame(correct + (opt.shape === target.shape && opt.color === target.color ? 1 : 0));
      return;
    }
    setRound(nextRound);
    makeRound(nextRound);
  }

  const progressPct = (timeLeft / ROUND_MS) * 100;

  return (
    <div className="flex flex-col items-center gap-5">
      {phase === "idle" && (
        <div className="flex flex-col items-center gap-4">
          <p className="text-white/50 text-sm text-center max-w-xs">
            Find the matching shape AND color in the grid before time runs out. {TOTAL_ROUNDS} rounds.
          </p>
          <button onClick={startGame} className="btn-primary px-8">Start</button>
        </div>
      )}

      {phase === "playing" && (
        <>
          <div className="flex items-center gap-6 text-sm">
            <span className="text-white/40">Round <span className="text-white font-medium">{round + 1}/{TOTAL_ROUNDS}</span></span>
            <span className="text-emerald-400 font-medium">✓ {correct}</span>
            <span className="text-red-400 font-medium">✗ {wrong}</span>
          </div>

          {/* Time bar */}
          <div className="w-64 h-1.5 bg-navy-800 rounded-full overflow-hidden">
            <div
              className={cn("h-full rounded-full transition-none", progressPct > 50 ? "bg-blue-electric" : progressPct > 25 ? "bg-yellow-400" : "bg-red-400")}
              style={{ width: `${progressPct}%` }}
            />
          </div>

          {/* Target */}
          <div className="text-center">
            <p className="text-white/40 text-xs mb-2 uppercase tracking-wider">Find this</p>
            <div className={cn(
              "w-20 h-20 rounded-xl border-2 flex items-center justify-center text-4xl transition-colors",
              flash === "correct" ? "border-emerald-400 bg-emerald-500/10" : flash === "wrong" ? "border-red-400 bg-red-500/10" : "border-white/20 bg-navy-800"
            )}>
              <span className={COLORS_CLASSES[target.color]}>{target.shape}</span>
            </div>
          </div>

          {/* Options */}
          <div className="grid grid-cols-2 gap-3">
            {options.map((opt, i) => (
              <button
                key={i}
                onClick={() => handleChoice(opt)}
                className="w-24 h-24 rounded-xl border border-white/10 bg-navy-800 flex items-center justify-center text-4xl hover:border-white/30 hover:bg-navy-750 transition-all active:scale-95"
              >
                <span className={COLORS_CLASSES[opt.color]}>{opt.shape}</span>
              </button>
            ))}
          </div>
        </>
      )}

      {phase === "done" && (
        <div className="text-center space-y-3">
          <p className="font-bold text-2xl text-white">
            {correct}/{TOTAL_ROUNDS} correct
          </p>
          <p className="text-white/40 text-sm">
            {Math.round((correct / TOTAL_ROUNDS) * 100)}% accuracy · {wrong} missed
          </p>
          <p className="text-white/30 text-xs">Results saved automatically</p>
        </div>
      )}
    </div>
  );
}
