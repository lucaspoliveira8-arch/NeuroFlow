"use client";
import { useState, useEffect, useCallback } from "react";
import type { MentalExerciseResult } from "@/types";
import { cn } from "@/lib/utils";

interface Props {
  onComplete: (result: Omit<MentalExerciseResult, "id" | "user_id" | "created_at">) => void;
}

const COLORS = [
  { id: 0, bg: "bg-blue-500", active: "bg-blue-300 shadow-[0_0_20px_rgba(147,197,253,0.6)]" },
  { id: 1, bg: "bg-violet-500", active: "bg-violet-300 shadow-[0_0_20px_rgba(196,181,253,0.6)]" },
  { id: 2, bg: "bg-emerald-500", active: "bg-emerald-300 shadow-[0_0_20px_rgba(110,231,183,0.6)]" },
  { id: 3, bg: "bg-rose-500", active: "bg-rose-300 shadow-[0_0_20px_rgba(253,164,175,0.6)]" },
];

type Phase = "idle" | "showing" | "input" | "result";

export function MemoryGame({ onComplete }: Props) {
  const [sequence, setSequence] = useState<number[]>([]);
  const [userInput, setUserInput] = useState<number[]>([]);
  const [activeCell, setActiveCell] = useState<number | null>(null);
  const [phase, setPhase] = useState<Phase>("idle");
  const [level, setLevel] = useState(1);
  const [score, setScore] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [total, setTotal] = useState(0);
  const [message, setMessage] = useState("");

  const flash = useCallback((cell: number, ms = 500) => {
    setActiveCell(cell);
    return new Promise<void>(res => setTimeout(() => { setActiveCell(null); res(); }, ms));
  }, []);

  const showSequence = useCallback(async (seq: number[]) => {
    setPhase("showing");
    await new Promise(r => setTimeout(r, 600));
    for (const cell of seq) {
      await flash(cell, 500);
      await new Promise(r => setTimeout(r, 200));
    }
    setPhase("input");
    setMessage("Your turn — repeat the sequence");
  }, [flash]);

  function startRound(lvl: number) {
    const seq = Array.from({ length: lvl + 2 }, () => Math.floor(Math.random() * 4));
    setSequence(seq);
    setUserInput([]);
    setMessage(`Level ${lvl} — watch carefully`);
    showSequence(seq);
  }

  function handleCellClick(id: number) {
    if (phase !== "input") return;
    flash(id, 200);
    const next = [...userInput, id];
    setUserInput(next);

    const idx = next.length - 1;
    if (next[idx] !== sequence[idx]) {
      // Wrong
      setTotal(t => t + 1);
      setMessage("❌ Wrong! Sequence failed.");
      setPhase("result");
      return;
    }

    if (next.length === sequence.length) {
      // Correct full sequence
      const pts = level * 10;
      setScore(s => s + pts);
      setCorrect(c => c + 1);
      setTotal(t => t + 1);
      setMessage(`✓ +${pts} pts`);
      setPhase("idle");
      setTimeout(() => {
        setLevel(l => l + 1);
        startRound(level + 1);
      }, 800);
    }
  }

  function finish() {
    const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;
    onComplete({ exercise_type: "memory_sequence", score, accuracy, reaction_time: null });
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex items-center gap-6 text-sm">
        <span className="text-current/40">Level <span className="text-current font-medium">{level}</span></span>
        <span className="text-current/40">Score <span className="text-yellow-400 font-medium">{score}</span></span>
        <span className="text-current/40">Correct <span className="text-emerald-400 font-medium">{correct}/{total}</span></span>
      </div>

      <p className="text-current/60 text-sm min-h-[1.5rem] text-center">{message}</p>

      <div className="grid grid-cols-2 gap-4">
        {COLORS.map((color) => (
          <button
            key={color.id}
            onClick={() => handleCellClick(color.id)}
            disabled={phase !== "input"}
            className={cn(
              "w-24 h-24 rounded-2xl transition-all duration-150 border-2 border-transparent",
              activeCell === color.id ? color.active : color.bg + " opacity-70",
              phase === "input" ? "cursor-pointer hover:opacity-90 hover:scale-105" : "cursor-default"
            )}
          />
        ))}
      </div>

      <div className="flex gap-3">
        {phase === "idle" && score === 0 && (
          <button onClick={() => startRound(level)} className="btn-primary px-6">
            Start Game
          </button>
        )}
        {phase === "result" && (
          <button onClick={finish} className="btn-primary px-6">
            Save Score & Exit
          </button>
        )}
        {(phase === "showing" || phase === "input") && (
          <button onClick={finish} className="btn-secondary px-6 text-sm">
            Finish & Save
          </button>
        )}
      </div>

      <p className="text-current/25 text-xs text-center max-w-xs">
        Watch the sequence of colored tiles light up, then repeat them in the same order.
      </p>
    </div>
  );
}
