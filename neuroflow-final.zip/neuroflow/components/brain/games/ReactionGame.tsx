"use client";
import { useState, useEffect, useRef } from "react";
import type { MentalExerciseResult } from "@/types";
import { cn } from "@/lib/utils";

interface Props {
  onComplete: (result: Omit<MentalExerciseResult, "id" | "user_id" | "created_at">) => void;
}

type Phase = "waiting" | "ready" | "go" | "result" | "tooEarly" | "done";

const ROUNDS = 5;

export function ReactionGame({ onComplete }: Props) {
  const [phase, setPhase] = useState<Phase>("waiting");
  const [times, setTimes] = useState<number[]>([]);
  const [startTime, setStartTime] = useState(0);
  const [lastTime, setLastTime] = useState(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => { if (timerRef.current) clearTimeout(timerRef.current); }, []);

  function beginRound() {
    setPhase("ready");
    const delay = 1500 + Math.random() * 2500;
    timerRef.current = setTimeout(() => {
      setPhase("go");
      setStartTime(Date.now());
    }, delay);
  }

  function handleClick() {
    if (phase === "waiting") {
      beginRound();
      return;
    }
    if (phase === "ready") {
      if (timerRef.current) clearTimeout(timerRef.current);
      setPhase("tooEarly");
      return;
    }
    if (phase === "go") {
      const rt = Date.now() - startTime;
      setLastTime(rt);
      const newTimes = [...times, rt];
      setTimes(newTimes);
      if (newTimes.length >= ROUNDS) {
        setPhase("done");
      } else {
        setPhase("result");
      }
      return;
    }
    if (phase === "result" || phase === "tooEarly") {
      beginRound();
    }
  }

  function finish() {
    const avg = times.length > 0 ? Math.round(times.reduce((a, b) => a + b, 0) / times.length) : 500;
    const best = times.length > 0 ? Math.min(...times) : 500;
    // Score: lower is better. Map 150–600ms → 100–0 pts
    const score = Math.max(0, Math.round(100 - ((avg - 150) / 450) * 100));
    const accuracy = Math.round((times.filter(t => t < 500).length / Math.max(times.length, 1)) * 100);
    onComplete({ exercise_type: "reaction_time", score, accuracy, reaction_time: avg });
  }

  const bgColor = {
    waiting: "bg-navy-800 border-white/10",
    ready: "bg-navy-800 border-yellow-500/30",
    go: "bg-emerald-500/20 border-emerald-400/50",
    result: "bg-navy-800 border-blue-neon/30",
    tooEarly: "bg-red-500/15 border-red-500/30",
    done: "bg-navy-800 border-white/10",
  }[phase];

  return (
    <div className="flex flex-col items-center gap-6">
      <div className="flex items-center gap-6 text-sm">
        <span className="text-white/40">Round <span className="text-white font-medium">{Math.min(times.length + 1, ROUNDS)}/{ROUNDS}</span></span>
        {times.length > 0 && (
          <span className="text-white/40">Last <span className="text-yellow-400 font-medium">{lastTime}ms</span></span>
        )}
        {times.length > 0 && (
          <span className="text-white/40">Avg <span className="text-blue-400 font-medium">{Math.round(times.reduce((a, b) => a + b, 0) / times.length)}ms</span></span>
        )}
      </div>

      <button
        onClick={handleClick}
        className={cn(
          "w-64 h-48 rounded-2xl border-2 transition-all duration-150 flex flex-col items-center justify-center gap-3 select-none",
          bgColor,
          phase === "go" ? "scale-105" : "hover:scale-102"
        )}
      >
        {phase === "waiting" && (
          <>
            <span className="text-4xl">👆</span>
            <span className="text-white/60 font-medium">Tap to Start</span>
          </>
        )}
        {phase === "ready" && (
          <>
            <span className="text-4xl animate-pulse-slow">⏳</span>
            <span className="text-yellow-400 font-medium">Get ready...</span>
            <span className="text-white/30 text-xs">Don&apos;t tap yet!</span>
          </>
        )}
        {phase === "go" && (
          <>
            <span className="text-5xl">⚡</span>
            <span className="text-emerald-300 font-bold text-2xl">TAP NOW!</span>
          </>
        )}
        {phase === "result" && (
          <>
            <span className="text-3xl font-bold text-blue-400">{lastTime}ms</span>
            <span className="text-white/50 text-sm">Tap to continue</span>
          </>
        )}
        {phase === "tooEarly" && (
          <>
            <span className="text-3xl">❌</span>
            <span className="text-red-400 font-medium">Too early!</span>
            <span className="text-white/40 text-sm">Tap to try again</span>
          </>
        )}
        {phase === "done" && (
          <>
            <span className="text-3xl">✓</span>
            <span className="text-emerald-400 font-medium">Done!</span>
            <span className="text-white/40 text-sm">Avg: {Math.round(times.reduce((a, b) => a + b, 0) / times.length)}ms</span>
          </>
        )}
      </button>

      {/* Times */}
      {times.length > 0 && (
        <div className="flex gap-2">
          {times.map((t, i) => (
            <div key={i} className={cn("px-2.5 py-1 rounded text-xs font-medium", t < 250 ? "bg-emerald-500/20 text-emerald-400" : t < 400 ? "bg-blue-500/20 text-blue-400" : "bg-white/5 text-white/50")}>
              {t}ms
            </div>
          ))}
        </div>
      )}

      {phase === "done" && (
        <button onClick={finish} className="btn-primary px-8">
          Save Results
        </button>
      )}

      <p className="text-white/25 text-xs text-center">
        When the box turns green and flashes ⚡, tap as fast as you can. {ROUNDS} rounds total.
      </p>
    </div>
  );
}
