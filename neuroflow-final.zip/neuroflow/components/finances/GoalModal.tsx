"use client";
import { useState } from "react";
import type { FinancialGoal } from "@/types";
import { Modal, Spinner } from "@/components/ui/index";
import { X } from "lucide-react";

interface Props {
  onSave: (p: Omit<FinancialGoal,"id"|"user_id"|"created_at">) => Promise<void>;
  onClose: () => void;
}

export function GoalModal({ onSave, onClose }: Props) {
  const [title,   setTitle]   = useState("");
  const [target,  setTarget]  = useState("");
  const [current, setCurrent] = useState("0");
  const [dl,      setDl]      = useState("");
  const [saving,  setSaving]  = useState(false);
  const [error,   setError]   = useState<string|null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const t = parseFloat(target); const c = parseFloat(current)||0;
    if (!title.trim()) { setError("Title required"); return; }
    if (!t || t <= 0)  { setError("Valid target required"); return; }
    setSaving(true); setError(null);
    try { await onSave({ title: title.trim(), target_amount: t, current_amount: c, deadline: dl||null }); }
    catch { setError("Failed to save"); setSaving(false); }
  }

  return (
    <Modal onClose={onClose}>
      <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: "1px solid var(--border)" }}>
        <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>New Financial Goal</h3>
        <button onClick={onClose} className="btn-ghost p-1"><X size={16} /></button>
      </div>
      <form onSubmit={handleSubmit} className="p-5 space-y-4">
        <div>
          <label className="label">Goal Title *</label>
          <input value={title} onChange={e => setTitle(e.target.value)} className="input" placeholder="Emergency fund, Vacation…" required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Target Amount *</label>
            <input type="number" min="1" value={target} onChange={e => setTarget(e.target.value)} className="input" placeholder="10000" required />
          </div>
          <div>
            <label className="label">Currently Saved</label>
            <input type="number" min="0" value={current} onChange={e => setCurrent(e.target.value)} className="input" placeholder="0" />
          </div>
        </div>
        <div>
          <label className="label">Target Date</label>
          <input type="date" value={dl} onChange={e => setDl(e.target.value)} className="input" />
        </div>
        {error && <p className="text-xs" style={{ color: "#f43f5e" }}>{error}</p>}
        <div className="flex gap-2 pt-1">
          <button type="button" onClick={onClose} className="btn-secondary flex-1 justify-center">Cancel</button>
          <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">
            {saving && <Spinner size={12} className="text-white" />}
            {saving ? "Creating…" : "Create Goal"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
