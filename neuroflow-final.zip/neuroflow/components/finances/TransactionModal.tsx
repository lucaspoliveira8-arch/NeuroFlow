"use client";
import { useState } from "react";
import type { FinancialTransaction, TransactionType } from "@/types";
import { Modal, Spinner } from "@/components/ui/index";
import { X } from "lucide-react";
import { todayKey } from "@/lib/dates";

const EXP = ["Food","Transport","Housing","Health","Entertainment","Shopping","Education","Utilities","Travel","Other"];
const INC = ["Salary","Freelance","Investment","Gift","Refund","Other"];

interface Props {
  onSave: (p: Omit<FinancialTransaction,"id"|"user_id"|"created_at">) => Promise<void>;
  onClose: () => void;
}

export function TransactionModal({ onSave, onClose }: Props) {
  const [type, setType]     = useState<TransactionType>("expense");
  const [amount, setAmount] = useState("");
  const [cat,  setCat]      = useState("");
  const [desc, setDesc]     = useState("");
  const [date, setDate]     = useState(todayKey());
  const [saving, setSaving] = useState(false);
  const [error,  setError]  = useState<string|null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) { setError("Valid amount required"); return; }
    if (!cat) { setError("Category required"); return; }
    setSaving(true); setError(null);
    try { await onSave({ type, amount: amt, category: cat, description: desc||null, date }); }
    catch { setError("Failed to save"); setSaving(false); }
  }

  return (
    <Modal onClose={onClose}>
      <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: "1px solid var(--border)" }}>
        <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Add Transaction</h3>
        <button onClick={onClose} className="btn-ghost p-1"><X size={16} /></button>
      </div>
      <form onSubmit={handleSubmit} className="p-5 space-y-4">
        {/* Type toggle */}
        <div className="flex rounded-[10px] p-1 gap-1" style={{ background: "var(--bg-subtle)" }}>
          {(["expense","income"] as TransactionType[]).map(t => (
            <button key={t} type="button" onClick={() => { setType(t); setCat(""); }}
              className="flex-1 py-2 rounded-lg text-xs font-semibold transition-all capitalize"
              style={{
                background: type === t ? "var(--bg-raised)" : "transparent",
                color: type === t ? (t === "income" ? "#10b981" : "#f43f5e") : "var(--text-tertiary)",
                boxShadow: type === t ? "var(--shadow-card)" : "none",
              }}>
              {t}
            </button>
          ))}
        </div>
        <div>
          <label className="label">Amount (USD) *</label>
          <input type="number" min="0.01" step="0.01" value={amount} onChange={e => setAmount(e.target.value)}
            className="input" placeholder="0.00" required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Category *</label>
            <select value={cat} onChange={e => setCat(e.target.value)} className="input select" required>
              <option value="">Select…</option>
              {(type === "income" ? INC : EXP).map(c => (
                <option key={c} value={c.toLowerCase()}>{c}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} className="input" />
          </div>
        </div>
        <div>
          <label className="label">Description</label>
          <input value={desc} onChange={e => setDesc(e.target.value)} className="input" placeholder="Optional note…" />
        </div>
        {error && <p className="text-xs" style={{ color: "#f43f5e" }}>{error}</p>}
        <div className="flex gap-2 pt-1">
          <button type="button" onClick={onClose} className="btn-secondary flex-1 justify-center">Cancel</button>
          <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">
            {saving && <Spinner size={12} className="text-white" />}
            {saving ? "Adding…" : "Add Transaction"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
