"use client";
import { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { BrainMark } from "@/components/ui/BrainMark";
import { useTheme } from "@/components/ui/ThemeProvider";
import { cn } from "@/lib/utils";
import { LayoutDashboard, CalendarDays, DollarSign, Brain, Bot, Settings, Menu, X, LogOut, Sun, Moon } from "lucide-react";

const NAV = [
  { href: "/app/dashboard", icon: LayoutDashboard, label: "Dashboard" },
  { href: "/app/planner",   icon: CalendarDays,    label: "Planner"   },
  { href: "/app/finances",  icon: DollarSign,      label: "Finances"  },
  { href: "/app/brain",     icon: Brain,           label: "Brain"     },
  { href: "/app/assistant", icon: Bot,             label: "AI Assistant" },
  { href: "/app/settings",  icon: Settings,        label: "Settings"  },
];

export function MobileNav() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const router   = useRouter();
  const { theme, toggle } = useTheme();

  async function logout() {
    await createClient().auth.signOut();
    router.push("/");
  }

  return (
    <div className="lg:hidden relative z-40">
      <div
        className="flex items-center justify-between px-4 h-14"
        style={{ background: "var(--bg-raised)", borderBottom: "1px solid var(--border)" }}
      >
        <div className="flex items-center gap-2" style={{ color: "var(--accent)" }}>
          <BrainMark size={22} />
          <span className="text-sm font-bold" style={{ color: "var(--text-primary)" }}>NeuroFlow</span>
        </div>
        <button onClick={() => setOpen(!open)} className="btn-ghost p-2">
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>
      {open && (
        <div
          className="absolute top-full left-0 right-0 px-3 pb-4 animate-fade-up"
          style={{ background: "var(--bg-raised)", borderBottom: "1px solid var(--border)" }}
        >
          <nav className="space-y-0.5 pt-3">
            {NAV.map(({ href, icon: Icon, label }) => (
              <Link key={href} href={href} onClick={() => setOpen(false)}
                className={cn("nav-link", pathname.startsWith(href) && "active")}>
                <Icon size={15} />
                {label}
              </Link>
            ))}
            <div className="pt-2 mt-2 space-y-1" style={{ borderTop: "1px solid var(--border)" }}>
              <button onClick={toggle} className="btn-ghost w-full justify-start text-xs">
                {theme === "dark" ? <><Sun size={13}/> Light mode</> : <><Moon size={13}/> Dark mode</>}
              </button>
              <button onClick={logout} className="btn-ghost w-full justify-start text-xs">
                <LogOut size={13} /> Sign out
              </button>
            </div>
          </nav>
        </div>
      )}
    </div>
  );
}
