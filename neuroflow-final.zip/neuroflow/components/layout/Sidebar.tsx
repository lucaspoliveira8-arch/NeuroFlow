"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { BrainMark } from "@/components/ui/BrainMark";
import { useTheme } from "@/components/ui/ThemeProvider";
import { cn } from "@/lib/utils";
import { LayoutDashboard, CalendarDays, DollarSign, Brain, Bot, Settings, LogOut, Sun, Moon } from "lucide-react";

const NAV = [
  { href:"/app/dashboard", icon:LayoutDashboard, label:"Dashboard"    },
  { href:"/app/planner",   icon:CalendarDays,    label:"Planner"      },
  { href:"/app/finances",  icon:DollarSign,      label:"Finances"     },
  { href:"/app/brain",     icon:Brain,           label:"Brain"        },
  { href:"/app/assistant", icon:Bot,             label:"AI Assistant" },
  { href:"/app/settings",  icon:Settings,        label:"Settings"     },
];

export function Sidebar({ userEmail }: { userEmail: string }) {
  const pathname = usePathname();
  const router   = useRouter();
  const { theme, toggle } = useTheme();

  async function logout() {
    await createClient().auth.signOut();
    router.push("/"); router.refresh();
  }

  const initials = userEmail.slice(0, 2).toUpperCase();

  return (
    <aside
      className="hidden lg:flex flex-col h-screen flex-shrink-0"
      style={{ width:"var(--sidebar-width)", background:"var(--bg-raised)", borderRight:"1px solid var(--border)" }}
    >
      {/* Brand */}
      <div
        className="flex items-center gap-2.5 px-4 h-14 flex-shrink-0"
        style={{ borderBottom:"1px solid var(--border)" }}
      >
        <div style={{ color:"var(--accent)" }}><BrainMark size={22} /></div>
        <span className="text-sm font-bold tracking-tight" style={{ color:"var(--text-primary)", letterSpacing:"-0.02em" }}>
          NeuroFlow
        </span>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2.5 py-3 space-y-0.5 overflow-y-auto">
        {NAV.map(({ href, icon:Icon, label }) => {
          const active = pathname.startsWith(href);
          return (
            <Link key={href} href={href} className={cn("nav-link", active && "active")}>
              <Icon size={14} strokeWidth={active ? 2.2 : 1.8} />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* Bottom */}
      <div className="px-2.5 pb-3 space-y-0.5" style={{ borderTop:"1px solid var(--border)", paddingTop:"10px" }}>
        <button onClick={toggle} className="btn-ghost w-full justify-start text-xs gap-2">
          {theme === "dark" ? <><Sun size={13}/> Light mode</> : <><Moon size={13}/> Dark mode</>}
        </button>
        {/* User row */}
        <div
          className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg mt-1"
          style={{ background:"var(--bg-subtle)" }}
        >
          <div
            className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0"
            style={{ background:"var(--accent-muted)", color:"var(--accent)" }}
          >
            {initials}
          </div>
          <p className="text-xs flex-1 truncate" style={{ color:"var(--text-secondary)" }}>{userEmail}</p>
          <button
            onClick={logout}
            className="p-1 rounded-md hover:opacity-70 transition-opacity flex-shrink-0"
            style={{ color:"var(--text-tertiary)" }}
            title="Sign out"
          >
            <LogOut size={12} />
          </button>
        </div>
      </div>
    </aside>
  );
}

// Shortcut hint at bottom of sidebar — visible to user
// Already added to Sidebar component body above
