"use client";
import { useState } from "react";
import { format, addMonths, subMonths, isSameDay, parseISO, isToday } from "date-fns";
import { getMonthDays, formatTime } from "@/lib/dates";
import type { Task, CalendarEvent } from "@/types";
import { cn } from "@/lib/utils";
import { ChevronLeft, ChevronRight, Trash2, Pencil, Plus } from "lucide-react";

interface Props {
  tasks: Task[];
  events: CalendarEvent[];
  onEditEvent: (e: CalendarEvent) => void;
  onDeleteEvent: (id: string) => void;
  onAddEvent: () => void;
}

export function CalendarView({ tasks, events, onEditEvent, onDeleteEvent, onAddEvent }: Props) {
  const [current,  setCurrent]  = useState(new Date());
  const [selected, setSelected] = useState(new Date());

  const days = getMonthDays(current.getFullYear(), current.getMonth());
  const dayTasks  = (d: Date) => tasks.filter(t => t.due_date && isSameDay(parseISO(t.due_date), d));
  const dayEvents = (d: Date) => events.filter(e => isSameDay(parseISO(e.start_time), d));

  const selTasks  = dayTasks(selected);
  const selEvents = dayEvents(selected).sort((a, b) => a.start_time.localeCompare(b.start_time));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Calendar */}
      <div className="lg:col-span-2 card p-5">
        <div className="flex items-center justify-between mb-5">
          <button onClick={() => setCurrent(subMonths(current, 1))} className="btn-ghost p-2"><ChevronLeft size={15} /></button>
          <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>{format(current, "MMMM yyyy")}</h3>
          <button onClick={() => setCurrent(addMonths(current, 1))} className="btn-ghost p-2"><ChevronRight size={15} /></button>
        </div>

        {/* Day headers */}
        <div className="grid grid-cols-7 mb-2">
          {["M","T","W","T","F","S","S"].map((d, i) => (
            <div key={i} className="text-center text-2xs font-semibold py-1" style={{ color: "var(--text-tertiary)" }}>{d}</div>
          ))}
        </div>

        {/* Days */}
        <div className="grid grid-cols-7 gap-1">
          {Array.from({ length: (days[0].getDay() + 6) % 7 }).map((_, i) => <div key={`e${i}`} />)}
          {days.map(day => {
            const hasTasks  = dayTasks(day).length  > 0;
            const hasEvents = dayEvents(day).length > 0;
            const sel       = isSameDay(day, selected);
            const tod       = isToday(day);
            return (
              <button key={day.toISOString()} onClick={() => setSelected(day)}
                className="aspect-square flex flex-col items-center justify-center rounded-lg text-xs transition-all relative"
                style={{
                  background: sel ? "var(--accent)" : tod ? "var(--accent-muted)" : "transparent",
                  color: sel ? "#fff" : tod ? "var(--accent)" : "var(--text-secondary)",
                  fontWeight: sel || tod ? 600 : 400,
                }}>
                {day.getDate()}
                {(hasTasks || hasEvents) && !sel && (
                  <div className="absolute bottom-1 flex gap-0.5">
                    {hasTasks  && <div className="w-1 h-1 rounded-full" style={{ background: "#f59e0b" }} />}
                    {hasEvents && <div className="w-1 h-1 rounded-full" style={{ background: "var(--accent)" }} />}
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Day panel */}
      <div className="card p-4 flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>{format(selected, "EEEE")}</p>
            <p className="text-xs" style={{ color: "var(--text-tertiary)" }}>{format(selected, "MMMM d, yyyy")}</p>
          </div>
          <button onClick={onAddEvent} className="btn-primary text-xs py-1.5 px-3">
            <Plus size={12} /> Event
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2">
          {selEvents.map(ev => (
            <div key={ev.id}
              className="flex items-start gap-2.5 p-3 rounded-[10px] group"
              style={{ background: "var(--bg-subtle)", border: "1px solid var(--border)" }}>
              <div className="w-0.5 self-stretch rounded-full flex-shrink-0" style={{ background: "var(--accent)" }} />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate" style={{ color: "var(--text-primary)" }}>{ev.title}</p>
                <p className="text-2xs mt-0.5" style={{ color: "var(--text-tertiary)" }}>
                  {formatTime(ev.start_time)} – {formatTime(ev.end_time)}
                </p>
              </div>
              <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => onEditEvent(ev)} className="btn-ghost p-1"><Pencil size={11} /></button>
                <button onClick={() => onDeleteEvent(ev.id)} className="btn-ghost p-1 hover:text-red-400"><Trash2 size={11} /></button>
              </div>
            </div>
          ))}
          {selTasks.map(t => (
            <div key={t.id}
              className="flex items-center gap-2.5 px-3 py-2.5 rounded-[10px]"
              style={{ background: "var(--bg-subtle)", border: "1px solid var(--border)" }}>
              <div className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                style={{ background: t.priority === "urgent" ? "#f43f5e" : t.priority === "high" ? "#f59e0b" : "var(--text-tertiary)" }} />
              <p className="text-xs flex-1 truncate" style={{ color: "var(--text-secondary)" }}>{t.title}</p>
              <span className="text-2xs capitalize" style={{ color: "var(--text-tertiary)" }}>{t.status}</span>
            </div>
          ))}
          {selEvents.length === 0 && selTasks.length === 0 && (
            <p className="text-xs text-center py-8" style={{ color: "var(--text-tertiary)" }}>Nothing scheduled</p>
          )}
        </div>
      </div>
    </div>
  );
}
