"use client";
import { useState } from "react";
import type { CalendarEvent } from "@/types";
import { Modal, Spinner } from "@/components/ui/index";
import { X } from "lucide-react";

interface Props {
  event?: CalendarEvent;
  onSave: (p: Omit<CalendarEvent, "id"|"user_id"|"created_at">) => Promise<void>;
  onClose: () => void;
}

export function EventModal({ event, onSave, onClose }: Props) {
  const fmt = (s: string) => s ? s.slice(0, 16) : "";
  const [title, setTitle] = useState(event?.title ?? "");
  const [desc,  setDesc]  = useState(event?.description ?? "");
  const [start, setStart] = useState(event ? fmt(event.start_time) : "");
  const [end,   setEnd]   = useState(event ? fmt(event.end_time)   : "");
  const [saving, setSaving] = useState(false);
  const [error,  setError]  = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim())    { setError("Title required"); return; }
    if (!start || !end)   { setError("Start and end time required"); return; }
    if (start >= end)     { setError("End must be after start"); return; }
    setSaving(true); setError(null);
    try {
      await onSave({ title: title.trim(), description: desc||null,
        start_time: new Date(start).toISOString(), end_time: new Date(end).toISOString() });
    } catch { setError("Failed to save"); setSaving(false); }
  }

  return (
    <Modal onClose={onClose}>
      <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: "1px solid var(--border)" }}>
        <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
          {event ? "Edit event" : "New event"}
        </h3>
        <button onClick={onClose} className="btn-ghost p-1"><X size={16} /></button>
      </div>
      <form onSubmit={handleSubmit} className="p-5 space-y-4">
        <div>
          <label className="label">Title *</label>
          <input value={title} onChange={e => setTitle(e.target.value)} className="input" placeholder="Event name…" required />
        </div>
        <div>
          <label className="label">Description</label>
          <textarea value={desc} onChange={e => setDesc(e.target.value)} className="input" rows={2} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Start *</label>
            <input type="datetime-local" value={start} onChange={e => setStart(e.target.value)} className="input" required />
          </div>
          <div>
            <label className="label">End *</label>
            <input type="datetime-local" value={end} onChange={e => setEnd(e.target.value)} className="input" required />
          </div>
        </div>
        {error && <p className="text-xs" style={{ color: "#f43f5e" }}>{error}</p>}
        <div className="flex gap-2 pt-1">
          <button type="button" onClick={onClose} className="btn-secondary flex-1 justify-center">Cancel</button>
          <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">
            {saving && <Spinner size={12} className="text-white" />}
            {saving ? "Saving…" : event ? "Update" : "Create event"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
