"use client";
import { useState } from "react";
import type { Task, TaskStatus, TaskPriority } from "@/types";
import { EmptyState, Badge } from "@/components/ui/index";
import { isOverdue, formatDisplay } from "@/lib/dates";
import { cn } from "@/lib/utils";
import { CheckCircle2, Circle, Clock, Pencil, Trash2, ClipboardList } from "lucide-react";

const PRIORITY_BADGE: Record<TaskPriority, { label: string; v: "red"|"amber"|"blue"|"gray" }> = {
  urgent: { label: "Urgent", v: "red"  },
  high:   { label: "High",   v: "amber"},
  medium: { label: "Medium", v: "blue" },
  low:    { label: "Low",    v: "gray" },
};

interface Props {
  tasks: Task[];
  onEdit: (t: Task) => void;
  onDelete: (id: string) => void;
  onToggle: (t: Task) => void;
  onAdd: () => void;
}

export function TaskList({ tasks, onEdit, onDelete, onToggle, onAdd }: Props) {
  const [fStatus,   setFStatus]   = useState<TaskStatus | "all">("all");
  const [fPriority, setFPriority] = useState<TaskPriority | "all">("all");
  const [sortBy,    setSortBy]    = useState<"due_date"|"priority">("due_date");

  const prioOrder: Record<TaskPriority, number> = { urgent:0, high:1, medium:2, low:3 };

  const filtered = tasks
    .filter(t => fStatus   === "all" || t.status   === fStatus)
    .filter(t => fPriority === "all" || t.priority === fPriority)
    .sort((a, b) => {
      if (sortBy === "priority") return prioOrder[a.priority] - prioOrder[b.priority];
      if (!a.due_date && !b.due_date) return 0;
      if (!a.due_date) return 1; if (!b.due_date) return -1;
      return a.due_date.localeCompare(b.due_date);
    });

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        {(["all","todo","in_progress","done"] as const).map(s => (
          <button key={s} onClick={() => setFStatus(s)}
            className="tag cursor-pointer transition-all"
            style={{
              background: fStatus === s ? "var(--accent-muted)" : "var(--bg-subtle)",
              color: fStatus === s ? "var(--accent)" : "var(--text-secondary)",
              border: `1px solid ${fStatus === s ? "var(--accent-border)" : "var(--border-strong)"}`,
            }}>
            {{ all:"All", todo:"To Do", in_progress:"In Progress", done:"Done" }[s]}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-2">
          <select value={fPriority} onChange={e => setFPriority(e.target.value as TaskPriority|"all")}
            className="input select text-xs py-1.5 px-2.5 w-auto">
            <option value="all">All priorities</option>
            <option value="urgent">Urgent</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          <select value={sortBy} onChange={e => setSortBy(e.target.value as "due_date"|"priority")}
            className="input select text-xs py-1.5 px-2.5 w-auto">
            <option value="due_date">Sort: Due date</option>
            <option value="priority">Sort: Priority</option>
          </select>
        </div>
        <span className="text-xs" style={{ color: "var(--text-tertiary)" }}>{filtered.length} task{filtered.length !== 1?"s":""}</span>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={<ClipboardList size={28} />} title="No tasks found"
          description="Create your first task to get started"
          action={<button onClick={onAdd} className="btn-primary text-xs">+ New task</button>} />
      ) : (
        <div className="space-y-2">
          {filtered.map(task => {
            const overdue = isOverdue(task.due_date) && task.status !== "done";
            const done    = task.status === "done";
            return (
              <div key={task.id}
                className="card group flex items-start gap-3 p-4 card-hover transition-all"
                style={{ opacity: done ? 0.6 : 1 }}>
                {/* Toggle */}
                <button onClick={() => onToggle(task)} className="mt-0.5 flex-shrink-0 transition-colors"
                  style={{ color: done ? "#10b981" : task.status === "in_progress" ? "#f59e0b" : "var(--text-tertiary)" }}>
                  {done ? <CheckCircle2 size={16} /> : task.status === "in_progress" ? <Clock size={16} /> : <Circle size={16} />}
                </button>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-0.5">
                    <span className={cn("text-sm font-medium", done && "line-through")}
                      style={{ color: done ? "var(--text-tertiary)" : "var(--text-primary)" }}>
                      {task.title}
                    </span>
                    <Badge variant={PRIORITY_BADGE[task.priority].v}>{PRIORITY_BADGE[task.priority].label}</Badge>
                    {overdue && <Badge variant="red">Overdue</Badge>}
                  </div>
                  {task.description && (
                    <p className="text-xs truncate" style={{ color: "var(--text-tertiary)" }}>{task.description}</p>
                  )}
                  <div className="flex items-center gap-3 mt-1">
                    {task.due_date && (
                      <span className="text-2xs" style={{ color: overdue ? "#f43f5e" : "var(--text-tertiary)" }}>
                        Due {formatDisplay(task.due_date)}
                      </span>
                    )}
                    {task.category && (
                      <span className="text-2xs px-1.5 py-0.5 rounded-md"
                        style={{ background: "var(--bg-subtle)", color: "var(--text-tertiary)" }}>
                        {task.category}
                      </span>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                  <button onClick={() => onEdit(task)} className="btn-ghost p-1.5"><Pencil size={12} /></button>
                  <button onClick={() => onDelete(task.id)} className="btn-ghost p-1.5 hover:text-red-400"><Trash2 size={12} /></button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
