"use client";
import { useState } from "react";
import type { Task, TaskStatus, TaskPriority } from "@/types";
import { Modal, Spinner } from "@/components/ui/index";
import { X } from "lucide-react";
import { todayKey } from "@/lib/dates";

interface Props {
  task?: Task;
  onSave: (p: Omit<Task, "id"|"user_id"|"created_at">) => Promise<void>;
  onClose: () => void;
}

export function TaskModal({ task, onSave, onClose }: Props) {
  const [title,   setTitle]   = useState(task?.title ?? "");
  const [desc,    setDesc]    = useState(task?.description ?? "");
  const [due,     setDue]     = useState(task?.due_date ?? "");
  const [priority,setPriority]= useState<TaskPriority>(task?.priority ?? "medium");
  const [cat,     setCat]     = useState(task?.category ?? "");
  const [status,  setStatus]  = useState<TaskStatus>(task?.status ?? "todo");
  const [saving,  setSaving]  = useState(false);
  const [error,   setError]   = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) { setError("Title is required"); return; }
    setSaving(true); setError(null);
    try {
      await onSave({ title: title.trim(), description: desc||null, due_date: due||null, priority, category: cat||null, status });
    } catch { setError("Failed to save"); setSaving(false); }
  }

  return (
    <Modal onClose={onClose}>
      <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: "1px solid var(--border)" }}>
        <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>
          {task ? "Edit task" : "New task"}
        </h3>
        <button onClick={onClose} className="btn-ghost p-1"><X size={16} /></button>
      </div>
      <form onSubmit={handleSubmit} className="p-5 space-y-4">
        <div>
          <label className="label">Title *</label>
          <input value={title} onChange={e => setTitle(e.target.value)} className="input" placeholder="Task title…" required />
        </div>
        <div>
          <label className="label">Description</label>
          <textarea value={desc} onChange={e => setDesc(e.target.value)} className="input" rows={2} placeholder="Optional notes…" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Priority</label>
            <select value={priority} onChange={e => setPriority(e.target.value as TaskPriority)} className="input select">
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="urgent">Urgent</option>
            </select>
          </div>
          <div>
            <label className="label">Status</label>
            <select value={status} onChange={e => setStatus(e.target.value as TaskStatus)} className="input select">
              <option value="todo">To Do</option>
              <option value="in_progress">In Progress</option>
              <option value="done">Done</option>
            </select>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label">Due Date</label>
            <input type="date" value={due} onChange={e => setDue(e.target.value)} className="input" />
          </div>
          <div>
            <label className="label">Category</label>
            <input value={cat} onChange={e => setCat(e.target.value)} className="input" placeholder="Work, Personal…" />
          </div>
        </div>
        {error && <p className="text-xs" style={{ color: "#f43f5e" }}>{error}</p>}
        <div className="flex gap-2 pt-1">
          <button type="button" onClick={onClose} className="btn-secondary flex-1 justify-center">Cancel</button>
          <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">
            {saving && <Spinner size={12} className="text-white" />}
            {saving ? "Saving…" : task ? "Update" : "Create task"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
