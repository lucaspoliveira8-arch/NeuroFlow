import { cn } from "@/lib/utils";

interface Props { size?: number; className?: string; }

// Clean geometric brain — two lobes, neural nodes, connection lines
// Works at any size, any color via currentColor
export function BrainMark({ size = 28, className }: Props) {
  return (
    <svg
      width={size} height={size} viewBox="0 0 32 32" fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn(className)}
      aria-label="NeuroFlow"
    >
      {/* Left lobe */}
      <path
        d="M16 7C10.5 7 6.5 10.8 6.5 15.2C6.5 18.5 8.5 21.2 11.5 22.3V25H16"
        stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"
      />
      {/* Right lobe */}
      <path
        d="M16 7C21.5 7 25.5 10.8 25.5 15.2C25.5 18.5 23.5 21.2 20.5 22.3V25H16"
        stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"
      />
      {/* Center line */}
      <line x1="16" y1="7" x2="16" y2="25" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeOpacity="0.4"/>
      {/* Neural nodes */}
      <circle cx="16" cy="11.5" r="1.6" fill="currentColor"/>
      <circle cx="10.5" cy="14"  r="1.4" fill="currentColor" fillOpacity="0.75"/>
      <circle cx="21.5" cy="14"  r="1.4" fill="currentColor" fillOpacity="0.75"/>
      <circle cx="10"   cy="19"  r="1.2" fill="currentColor" fillOpacity="0.5"/>
      <circle cx="22"   cy="19"  r="1.2" fill="currentColor" fillOpacity="0.5"/>
      {/* Connections */}
      <line x1="16"   y1="11.5" x2="10.5" y2="14" stroke="currentColor" strokeWidth="0.9" strokeOpacity="0.3"/>
      <line x1="16"   y1="11.5" x2="21.5" y2="14" stroke="currentColor" strokeWidth="0.9" strokeOpacity="0.3"/>
      <line x1="10.5" y1="14"   x2="10"   y2="19" stroke="currentColor" strokeWidth="0.9" strokeOpacity="0.25"/>
      <line x1="21.5" y1="14"   x2="22"   y2="19" stroke="currentColor" strokeWidth="0.9" strokeOpacity="0.25"/>
    </svg>
  );
}
