"use client";
import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { matchesShortcut } from "@/lib/keyboard";
import { X, Command } from "lucide-react";

// Command palette items
const NAV_SHORTCUTS = [
  { key: "1", meta: true, description: "Go to Dashboard",   path: "/app/dashboard" },
  { key: "2", meta: true, description: "Go to Planner",     path: "/app/planner" },
  { key: "3", meta: true, description: "Go to Finances",    path: "/app/finances" },
  { key: "4", meta: true, description: "Go to Brain",       path: "/app/brain" },
  { key: "5", meta: true, description: "Open AI Assistant", path: "/app/assistant" },
];

interface ShortcutsModalProps { onClose: () => void; }

function ShortcutsModal({ onClose }: ShortcutsModalProps) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(8px)" }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="card w-full max-w-sm p-6 animate-scale-in" style={{ boxShadow: "var(--shadow-modal)" }}>
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <Command size={15} style={{ color: "var(--accent)" }} />
            <h3 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Keyboard Shortcuts</h3>
          </div>
          <button onClick={onClose} className="btn-ghost p-1"><X size={14} /></button>
        </div>
        <div className="space-y-1">
          {[
            { keys: ["⌘", "K"],       desc: "Open command palette" },
            { keys: ["⌘", "1"],       desc: "Dashboard" },
            { keys: ["⌘", "2"],       desc: "Planner" },
            { keys: ["⌘", "3"],       desc: "Finances" },
            { keys: ["⌘", "4"],       desc: "Brain" },
            { keys: ["⌘", "5"],       desc: "AI Assistant" },
            { keys: ["?"],            desc: "Show shortcuts" },
            { keys: ["Esc"],          desc: "Close modal / panel" },
          ].map(({ keys, desc }) => (
            <div key={desc} className="flex items-center justify-between py-2"
              style={{ borderBottom: "1px solid var(--border)" }}>
              <span className="text-xs" style={{ color: "var(--text-secondary)" }}>{desc}</span>
              <div className="flex items-center gap-1">
                {keys.map(k => (
                  <kbd key={k}
                    className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold"
                    style={{ background: "var(--bg-subtle)", border: "1px solid var(--border-strong)", color: "var(--text-tertiary)" }}>
                    {k}
                  </kbd>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Command palette
interface CommandItem {
  id: string;
  label: string;
  desc?: string;
  action: () => void;
  icon?: string;
}

interface PaletteProps { onClose: () => void; items: CommandItem[]; }

function CommandPalette({ onClose, items }: PaletteProps) {
  const [query, setQuery] = useState("");
  const [sel,   setSel]   = useState(0);

  const filtered = items.filter(i =>
    i.label.toLowerCase().includes(query.toLowerCase()) ||
    (i.desc?.toLowerCase().includes(query.toLowerCase()))
  );

  useEffect(() => { setSel(0); }, [query]);

  useEffect(() => {
    function handler(e: KeyboardEvent) {
      if (e.key === "ArrowDown") { e.preventDefault(); setSel(s => Math.min(s + 1, filtered.length - 1)); }
      if (e.key === "ArrowUp")   { e.preventDefault(); setSel(s => Math.max(s - 1, 0)); }
      if (e.key === "Enter" && filtered[sel]) { filtered[sel].action(); onClose(); }
    }
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [filtered, sel, onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-[15vh] px-4"
      style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(8px)" }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="card w-full max-w-md overflow-hidden animate-fade-up" style={{ boxShadow: "var(--shadow-modal)" }}>
        <div className="flex items-center gap-3 px-4 py-3.5" style={{ borderBottom: "1px solid var(--border)" }}>
          <Command size={15} style={{ color: "var(--text-tertiary)" }} />
          <input
            autoFocus
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search pages, actions…"
            className="flex-1 bg-transparent outline-none text-sm"
            style={{ color: "var(--text-primary)" }}
          />
          <kbd className="text-[10px] px-1.5 py-0.5 rounded font-mono"
            style={{ background: "var(--bg-subtle)", border: "1px solid var(--border-strong)", color: "var(--text-tertiary)" }}>
            Esc
          </kbd>
        </div>
        <div className="max-h-72 overflow-y-auto py-1.5">
          {filtered.length === 0 ? (
            <p className="text-xs text-center py-8" style={{ color: "var(--text-tertiary)" }}>No results for &quot;{query}&quot;</p>
          ) : filtered.map((item, i) => (
            <button
              key={item.id}
              onClick={() => { item.action(); onClose(); }}
              className="w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors"
              style={{ background: i === sel ? "var(--accent-muted)" : "transparent" }}
              onMouseEnter={() => setSel(i)}
            >
              {item.icon && <span className="text-base w-5 text-center">{item.icon}</span>}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium" style={{ color: "var(--text-primary)" }}>{item.label}</p>
                {item.desc && <p className="text-xs" style={{ color: "var(--text-tertiary)" }}>{item.desc}</p>}
              </div>
            </button>
          ))}
        </div>
        <div className="px-4 py-2.5 flex items-center gap-4 text-xs" style={{ borderTop: "1px solid var(--border)", color: "var(--text-tertiary)" }}>
          <span className="flex items-center gap-1"><kbd className="px-1 rounded" style={{ background:"var(--bg-subtle)", border:"1px solid var(--border-strong)" }}>↑↓</kbd> navigate</span>
          <span className="flex items-center gap-1"><kbd className="px-1 rounded" style={{ background:"var(--bg-subtle)", border:"1px solid var(--border-strong)" }}>↵</kbd> select</span>
          <span className="flex items-center gap-1"><kbd className="px-1 rounded" style={{ background:"var(--bg-subtle)", border:"1px solid var(--border-strong)" }}>Esc</kbd> close</span>
        </div>
      </div>
    </div>
  );
}

// Main hook + component
export function KeyboardShortcutsProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [showHelp,    setShowHelp]    = useState(false);
  const [showPalette, setShowPalette] = useState(false);

  const paletteItems: CommandItem[] = [
    { id:"dash",   label:"Dashboard",      desc:"Overview of your day",               icon:"⬛", action:() => router.push("/app/dashboard") },
    { id:"plan",   label:"Planner",        desc:"Tasks and calendar",                 icon:"📅", action:() => router.push("/app/planner") },
    { id:"fin",    label:"Finances",       desc:"Income, expenses, goals",            icon:"💰", action:() => router.push("/app/finances") },
    { id:"brain",  label:"Brain",          desc:"Cognitive metrics and sleep",        icon:"🧠", action:() => router.push("/app/brain") },
    { id:"ai",     label:"AI Assistant",   desc:"Ask anything, create tasks/events",  icon:"🤖", action:() => router.push("/app/assistant") },
    { id:"set",    label:"Settings",       desc:"Profile and preferences",            icon:"⚙️", action:() => router.push("/app/settings") },
  ];

  const handleKey = useCallback((e: KeyboardEvent) => {
    // Don't fire in inputs
    const tag = (e.target as HTMLElement).tagName;
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;

    // ⌘K / Ctrl+K → command palette
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
      e.preventDefault();
      setShowPalette(p => !p);
      return;
    }

    // ? → shortcuts modal
    if (e.key === "?" && !e.metaKey && !e.ctrlKey) {
      setShowHelp(h => !h);
      return;
    }

    // Esc → close everything
    if (e.key === "Escape") {
      setShowHelp(false);
      setShowPalette(false);
      return;
    }

    // Nav shortcuts ⌘1-5
    for (const s of NAV_SHORTCUTS) {
      if (matchesShortcut(e, { ...s, action: () => {} })) {
        e.preventDefault();
        router.push(s.path);
        return;
      }
    }
  }, [router]);

  useEffect(() => {
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [handleKey]);

  return (
    <>
      {children}
      {showHelp    && <ShortcutsModal  onClose={() => setShowHelp(false)} />}
      {showPalette && <CommandPalette  onClose={() => setShowPalette(false)} items={paletteItems} />}
    </>
  );
}
