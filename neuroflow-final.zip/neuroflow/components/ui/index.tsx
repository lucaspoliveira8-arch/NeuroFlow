"use client";
import { cn } from "@/lib/utils";
import { Loader2, AlertCircle, CheckCircle, Info, X } from "lucide-react";
import React, { useEffect, useState } from "react";

/* ── Card ────────────────────────────────────────────────────────── */
export function Card({ children, className, onClick }: {
  children: React.ReactNode; className?: string; onClick?: () => void;
}) {
  return (
    <div
      className={cn("card", onClick && "card-interactive", className)}
      onClick={onClick}
    >
      {children}
    </div>
  );
}

/* ── Spinner ─────────────────────────────────────────────────────── */
export function Spinner({ size = 16, className }: { size?: number; className?: string }) {
  return (
    <svg
      className={cn("animate-spin", className)}
      style={{ color: "var(--accent)" }}
      width={size} height={size} viewBox="0 0 16 16" fill="none"
    >
      <circle cx="8" cy="8" r="6" stroke="currentColor" strokeOpacity="0.2" strokeWidth="2"/>
      <path d="M14 8A6 6 0 0 0 8 2" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  );
}

/* ── Loading state ───────────────────────────────────────────────── */
export function LoadingState({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-24 gap-3 animate-fade-in">
      <Spinner size={20} />
      <p className="text-xs" style={{ color: "var(--text-tertiary)" }}>{label}</p>
    </div>
  );
}

/* ── Skeleton ────────────────────────────────────────────────────── */
export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton", className)} />;
}

/* ── Empty state ─────────────────────────────────────────────────── */
export function EmptyState({
  icon, title, description, action,
}: {
  icon?: React.ReactNode; title: string;
  description?: string; action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-2.5 text-center px-4 animate-fade-in">
      {icon && (
        <div className="mb-1 p-3 rounded-2xl" style={{ background: "var(--bg-subtle)", color: "var(--text-tertiary)" }}>
          {icon}
        </div>
      )}
      <p className="text-sm font-semibold" style={{ color: "var(--text-secondary)" }}>{title}</p>
      {description && (
        <p className="text-xs max-w-[220px] leading-relaxed" style={{ color: "var(--text-tertiary)" }}>
          {description}
        </p>
      )}
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}

/* ── Toast ───────────────────────────────────────────────────────── */
interface ToastProps {
  type?: "success" | "error" | "info";
  message: string;
  onClose?: () => void;
}
export function Toast({ type = "success", message, onClose }: ToastProps) {
  const config = {
    success: { icon: CheckCircle,   bg: "rgba(16,185,129,0.09)",  border: "rgba(16,185,129,0.20)", color: "#059669" },
    error:   { icon: AlertCircle,   bg: "rgba(239,68,68,0.09)",   border: "rgba(239,68,68,0.20)",  color: "#dc2626" },
    info:    { icon: Info,          bg: "rgba(37,99,235,0.09)",   border: "rgba(37,99,235,0.20)",  color: "var(--accent)" },
  }[type];
  const Icon = config.icon;
  return (
    <div
      className="flex items-start gap-3 px-4 py-3 rounded-xl text-sm animate-fade-up"
      style={{ background: config.bg, border: `1px solid ${config.border}` }}
    >
      <Icon size={15} style={{ color: config.color, flexShrink: 0, marginTop: 1 }} />
      <span className="flex-1 text-xs leading-relaxed" style={{ color: "var(--text-primary)" }}>{message}</span>
      {onClose && (
        <button onClick={onClose} className="btn-ghost p-0 w-5 h-5 flex items-center justify-center flex-shrink-0">
          <X size={12} />
        </button>
      )}
    </div>
  );
}

/* ── Auto-dismiss toast ──────────────────────────────────────────── */
export function AutoToast({ type, message, duration = 3000, onDone }: ToastProps & { duration?: number; onDone?: () => void }) {
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => { setVisible(false); onDone?.(); }, duration);
    return () => clearTimeout(t);
  }, [duration, onDone]);
  if (!visible) return null;
  return <Toast type={type} message={message} onClose={() => { setVisible(false); onDone?.(); }} />;
}

/* ── Metric card ─────────────────────────────────────────────────── */
export function MetricCard({
  label, value, suffix = "", color, subLabel, barValue, barColor,
}: {
  label: string; value: number | string; suffix?: string;
  color?: string; subLabel?: string; barValue?: number; barColor?: string;
}) {
  return (
    <Card className="p-5">
      <p className="section-heading mb-3">{label}</p>
      <div className={cn("text-[28px] font-bold tabular-nums leading-none", color)}>
        {value}
        {suffix && <span className="text-sm font-medium opacity-60 ml-0.5">{suffix}</span>}
      </div>
      {subLabel && <p className="text-xs mt-1.5" style={{ color: "var(--text-tertiary)" }}>{subLabel}</p>}
      {barValue !== undefined && (
        <div className="score-bar mt-3.5">
          <div
            className="score-bar-fill"
            style={{ width: `${Math.min(100,Math.max(0,barValue))}%`, background: barColor ?? "var(--accent)" }}
          />
        </div>
      )}
    </Card>
  );
}

/* ── Badge ───────────────────────────────────────────────────────── */
export function Badge({ children, variant = "gray" }: {
  children: React.ReactNode;
  variant?: "gray" | "blue" | "green" | "amber" | "red" | "violet";
}) {
  const cls = { gray:"tag-gray", blue:"tag-blue", green:"tag-green", amber:"tag-amber", red:"tag-red", violet:"tag-violet" }[variant];
  return <span className={cn("tag", cls)}>{children}</span>;
}

/* ── Section header ──────────────────────────────────────────────── */
export function SectionHeader({ title, description, action }: {
  title: string; description?: string; action?: React.ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-4 mb-5">
      <div>
        <h2 className="text-[15px] font-semibold leading-snug" style={{ color: "var(--text-primary)" }}>{title}</h2>
        {description && <p className="text-xs mt-0.5" style={{ color: "var(--text-tertiary)" }}>{description}</p>}
      </div>
      {action && <div className="flex-shrink-0">{action}</div>}
    </div>
  );
}

/* ── Modal ───────────────────────────────────────────────────────── */
export function Modal({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  // Close on Escape
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in"
      style={{ background: "rgba(0,0,0,0.5)", backdropFilter: "blur(8px)" }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        className="card w-full max-w-md animate-scale-in"
        style={{ boxShadow: "var(--shadow-modal)" }}
      >
        {children}
      </div>
    </div>
  );
}

/* ── Kbd ─────────────────────────────────────────────────────────── */
export function Kbd({ children }: { children: React.ReactNode }) {
  return (
    <kbd
      className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-mono font-medium"
      style={{ background: "var(--bg-subtle)", border: "1px solid var(--border-strong)", color: "var(--text-tertiary)" }}
    >
      {children}
    </kbd>
  );
}
