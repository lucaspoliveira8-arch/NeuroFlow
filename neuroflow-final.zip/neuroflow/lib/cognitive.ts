import type { SleepLog, MentalExerciseResult } from "@/types";

export interface CognitiveMetrics {
  cognitiveScore: number;
  focusScore: number;
  fatigueScore: number;
  burnoutRisk: number;
}

export function computeCognitiveMetrics(
  recentSleepLogs: SleepLog[],
  recentExercises: MentalExerciseResult[]
): CognitiveMetrics {
  // Sleep analysis
  const last7Sleep = recentSleepLogs.slice(0, 7);
  const avgHours =
    last7Sleep.length > 0
      ? last7Sleep.reduce((s, l) => s + l.hours_slept, 0) / last7Sleep.length
      : 7;
  const avgQuality =
    last7Sleep.length > 0
      ? last7Sleep.reduce((s, l) => s + l.sleep_quality, 0) / last7Sleep.length
      : 3;

  // Sleep consistency (std dev penalty)
  const hoursVariance =
    last7Sleep.length > 1
      ? last7Sleep.reduce((s, l) => s + Math.pow(l.hours_slept - avgHours, 2), 0) /
        last7Sleep.length
      : 0;
  const consistencyPenalty = Math.min(hoursVariance * 3, 20);

  // Exercise performance
  const recentEx = recentExercises.slice(0, 10);
  const avgAccuracy =
    recentEx.length > 0
      ? recentEx.reduce((s, e) => s + e.accuracy, 0) / recentEx.length
      : 70;
  const avgReactionMs =
    recentEx.filter((e) => e.reaction_time).length > 0
      ? recentEx
          .filter((e) => e.reaction_time)
          .reduce((s, e) => s + (e.reaction_time || 0), 0) /
        recentEx.filter((e) => e.reaction_time).length
      : 400;

  // Scoring
  const sleepScore = Math.min(
    100,
    (avgHours / 8) * 50 + (avgQuality / 5) * 50 - consistencyPenalty
  );
  const exerciseScore = Math.min(
    100,
    avgAccuracy * 0.6 + Math.max(0, (600 - avgReactionMs) / 6)
  );

  const cognitiveScore = Math.round(sleepScore * 0.5 + exerciseScore * 0.5);
  const focusScore = Math.round(
    avgAccuracy * 0.7 + (avgQuality / 5) * 30
  );
  const fatigueScore = Math.round(
    Math.max(
      0,
      100 - (avgHours / 8) * 50 - (avgQuality / 5) * 30 + consistencyPenalty
    )
  );

  // Burnout risk: high fatigue + low sleep + low quality over time
  const burnoutRisk = Math.round(
    Math.min(
      100,
      fatigueScore * 0.5 +
        Math.max(0, (8 - avgHours) * 8) +
        Math.max(0, (3 - avgQuality) * 5)
    )
  );

  return {
    cognitiveScore: clamp(cognitiveScore, 0, 100),
    focusScore: clamp(focusScore, 0, 100),
    fatigueScore: clamp(fatigueScore, 0, 100),
    burnoutRisk: clamp(burnoutRisk, 0, 100),
  };
}

function clamp(val: number, min: number, max: number): number {
  return Math.min(Math.max(Math.round(val), min), max);
}

export function scoreColor(score: number, invert = false): string {
  const effective = invert ? 100 - score : score;
  if (effective >= 75) return "text-emerald-400";
  if (effective >= 50) return "text-yellow-400";
  return "text-red-400";
}

export function scoreBarColor(score: number, invert = false): string {
  const effective = invert ? 100 - score : score;
  if (effective >= 75) return "bg-emerald-500";
  if (effective >= 50) return "bg-yellow-500";
  return "bg-red-500";
}
