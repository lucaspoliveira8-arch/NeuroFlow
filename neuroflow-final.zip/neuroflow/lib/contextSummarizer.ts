import type {
  Task, CalendarEvent, FinancialTransaction,
  FinancialGoal, SleepLog, MentalExerciseResult, CognitiveDailyStatus,
} from "@/types";
import { formatDisplay, formatCurrency } from "@/lib/dates";

export interface AppContext {
  tasks?: Task[];
  events?: CalendarEvent[];
  transactions?: FinancialTransaction[];
  goals?: FinancialGoal[];
  sleepLogs?: SleepLog[];
  exercises?: MentalExerciseResult[];
  cognitiveStatus?: CognitiveDailyStatus | null;
  profile?: { full_name?: string | null };
}

export function buildContextSummary(ctx: AppContext): string {
  const parts: string[] = [];

  if (ctx.profile?.full_name) parts.push(`User: ${ctx.profile.full_name}`);

  if (ctx.tasks && ctx.tasks.length > 0) {
    const open   = ctx.tasks.filter(t => t.status !== "done");
    const urgent = open.filter(t => t.priority === "urgent" || t.priority === "high");
    parts.push(`Tasks: ${ctx.tasks.length} total, ${open.length} open, ${urgent.length} high/urgent priority.`);
    if (urgent.length > 0)
      parts.push(`Top urgent: ${urgent.slice(0,3).map(t => `"${t.title}"${t.due_date?` (due ${formatDisplay(t.due_date)})`:""}` ).join(", ")}`);
  }

  if (ctx.events && ctx.events.length > 0) {
    const upcoming = ctx.events.filter(e => new Date(e.start_time) >= new Date()).slice(0,3);
    if (upcoming.length > 0)
      parts.push(`Upcoming events: ${upcoming.map(e => `"${e.title}" on ${formatDisplay(e.start_time,"MMM d")}`).join(", ")}`);
  }

  if (ctx.transactions && ctx.transactions.length > 0) {
    const inc = ctx.transactions.filter(t => t.type==="income").reduce((s,t)=>s+t.amount,0);
    const exp = ctx.transactions.filter(t => t.type==="expense").reduce((s,t)=>s+t.amount,0);
    parts.push(`Finances: Balance ${formatCurrency(inc-exp)}, Income ${formatCurrency(inc)}, Expenses ${formatCurrency(exp)}.`);
  }

  if (ctx.goals && ctx.goals.length > 0)
    parts.push(`Goals: ${ctx.goals.slice(0,3).map(g=>`"${g.title}" ${Math.round(g.current_amount/g.target_amount*100)}%`).join("; ")}`);

  if (ctx.sleepLogs && ctx.sleepLogs.length > 0) {
    const r = ctx.sleepLogs.slice(0,7);
    parts.push(`Sleep 7-day avg: ${(r.reduce((s,l)=>s+l.hours_slept,0)/r.length).toFixed(1)}h, quality ${(r.reduce((s,l)=>s+l.sleep_quality,0)/r.length).toFixed(1)}/5`);
  }

  if (ctx.cognitiveStatus) {
    const cs = ctx.cognitiveStatus;
    parts.push(`Cognitive today: score ${cs.cognitive_score}, focus ${cs.focus_score}, fatigue ${cs.fatigue_score}, burnout risk ${cs.burnout_risk}`);
  }

  return parts.join("\n");
}

// ─── Tool definitions for OpenAI function calling ────────────────────────────
export const TOOLS = [
  {
    type: "function" as const,
    function: {
      name: "create_task",
      description: "Create a new task for the user in their planner",
      parameters: {
        type: "object",
        properties: {
          title:       { type: "string",  description: "Task title" },
          description: { type: "string",  description: "Optional description" },
          due_date:    { type: "string",  description: "Due date in YYYY-MM-DD format, optional" },
          priority:    { type: "string",  enum: ["low","medium","high","urgent"], description: "Priority level" },
          category:    { type: "string",  description: "Category like Work, Personal, Health, etc." },
        },
        required: ["title"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "create_event",
      description: "Create a calendar event for the user",
      parameters: {
        type: "object",
        properties: {
          title:       { type: "string", description: "Event title" },
          description: { type: "string", description: "Optional description" },
          start_time:  { type: "string", description: "Start datetime in ISO 8601 format (e.g. 2024-03-15T14:00:00)" },
          end_time:    { type: "string", description: "End datetime in ISO 8601 format" },
        },
        required: ["title","start_time","end_time"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "create_transaction",
      description: "Add a financial transaction (income or expense) for the user",
      parameters: {
        type: "object",
        properties: {
          type:        { type: "string", enum: ["income","expense"], description: "Transaction type" },
          amount:      { type: "number", description: "Amount in USD" },
          category:    { type: "string", description: "Category like food, transport, salary, etc." },
          description: { type: "string", description: "Optional description" },
          date:        { type: "string", description: "Date in YYYY-MM-DD format, defaults to today" },
        },
        required: ["type","amount","category"],
      },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "list_tasks",
      description: "Get the user's current task list to answer questions about them",
      parameters: { type: "object", properties: {} },
    },
  },
  {
    type: "function" as const,
    function: {
      name: "get_financial_summary",
      description: "Get the user's financial summary with balance, income, and expenses",
      parameters: { type: "object", properties: {} },
    },
  },
] as const;

export type ToolName = "create_task" | "create_event" | "create_transaction" | "list_tasks" | "get_financial_summary";

export const SYSTEM_PROMPT = `You are NeuroFlow AI — a smart, helpful personal assistant built into the NeuroFlow productivity app.

You can help with ANYTHING the user asks — general knowledge, coding, writing, advice, math, planning, creative tasks, analysis, and more. You are also aware of the user's personal data in the app.

## Your capabilities:
1. **General assistant** — answer any question on any topic, like ChatGPT
2. **App-aware** — you have context of the user's tasks, finances, sleep, and cognitive data
3. **Action taker** — you can CREATE tasks, events, and transactions directly when the user asks

## When to take actions:
- User says "create a task", "add a task", "remind me to", "I need to" → use create_task
- User says "schedule", "add an event", "book", "set a meeting" → use create_event  
- User says "log expense", "I spent", "add income", "record a transaction" → use create_transaction

## Tone:
- Conversational and natural for general questions
- Precise and action-oriented for productivity tasks
- Never robotic, never overly formal
- Concise unless depth is needed

## Important:
- For general questions (weather, history, coding, etc.) just answer directly — no need for app context
- When you create something, confirm it clearly: "✓ Task created: [title]"
- Today's date context will be provided in the system context below
- If user data context is available, reference it when relevant`;
