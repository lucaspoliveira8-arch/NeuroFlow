import { format, parseISO, startOfMonth, endOfMonth, eachDayOfInterval, isToday, isBefore, startOfWeek, endOfWeek } from "date-fns";

export function toLocalDateKey(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return format(d, "yyyy-MM-dd");
}

export function todayKey(): string {
  return toLocalDateKey(new Date());
}

export function formatDisplay(date: Date | string, fmt = "MMM d, yyyy"): string {
  const d = typeof date === "string" ? parseISO(date) : date;
  return format(d, fmt);
}

export function formatTime(date: Date | string): string {
  const d = typeof date === "string" ? parseISO(date) : date;
  return format(d, "h:mm a");
}

export function getMonthDays(year: number, month: number): Date[] {
  const start = startOfMonth(new Date(year, month));
  const end = endOfMonth(new Date(year, month));
  return eachDayOfInterval({ start, end });
}

export function getWeekDays(date: Date): Date[] {
  const start = startOfWeek(date, { weekStartsOn: 1 });
  const end = endOfWeek(date, { weekStartsOn: 1 });
  return eachDayOfInterval({ start, end });
}

export function isOverdue(dateStr: string | null): boolean {
  if (!dateStr) return false;
  return isBefore(parseISO(dateStr), new Date()) && !isToday(parseISO(dateStr));
}

export function groupByMonth(
  items: Array<{ date: string; amount: number; type: string }>
): Array<{ month: string; income: number; expense: number }> {
  const map = new Map<string, { income: number; expense: number }>();

  items.forEach((item) => {
    const key = format(parseISO(item.date), "MMM yyyy");
    const existing = map.get(key) || { income: 0, expense: 0 };
    if (item.type === "income") existing.income += item.amount;
    else existing.expense += item.amount;
    map.set(key, existing);
  });

  return Array.from(map.entries())
    .map(([month, data]) => ({ month, ...data }))
    .slice(-6);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}
