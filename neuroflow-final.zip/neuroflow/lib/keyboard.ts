// Global keyboard shortcuts for NeuroFlow
// Usage: import and call registerShortcuts() in a client component

export interface Shortcut {
  key: string;
  meta?: boolean;
  ctrl?: boolean;
  shift?: boolean;
  description: string;
  action: () => void;
}

export function matchesShortcut(e: KeyboardEvent, s: Shortcut): boolean {
  const metaOrCtrl = e.metaKey || e.ctrlKey;
  if (s.meta && !metaOrCtrl) return false;
  if (s.shift && !e.shiftKey) return false;
  if (!s.meta && metaOrCtrl) return false;
  return e.key.toLowerCase() === s.key.toLowerCase();
}
