-- NeuroFlow Database Schema
-- Run this in your Supabase SQL editor

-- Enable RLS
alter default privileges in schema public grant all on tables to postgres, anon, authenticated, service_role;

-- Profiles
create table if not exists profiles (
  id uuid references auth.users(id) on delete cascade primary key,
  full_name text,
  email text,
  created_at timestamptz default now() not null
);

alter table profiles enable row level security;
create policy "Users can view own profile" on profiles for select using (auth.uid() = id);
create policy "Users can insert own profile" on profiles for insert with check (auth.uid() = id);
create policy "Users can update own profile" on profiles for update using (auth.uid() = id);

-- Tasks
create table if not exists tasks (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  title text not null,
  description text,
  due_date date,
  priority text check (priority in ('low','medium','high','urgent')) default 'medium',
  category text,
  status text check (status in ('todo','in_progress','done')) default 'todo',
  created_at timestamptz default now() not null
);

alter table tasks enable row level security;
create policy "Users can manage own tasks" on tasks for all using (auth.uid() = user_id);

-- Calendar Events
create table if not exists calendar_events (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  title text not null,
  description text,
  start_time timestamptz not null,
  end_time timestamptz not null,
  created_at timestamptz default now() not null
);

alter table calendar_events enable row level security;
create policy "Users can manage own events" on calendar_events for all using (auth.uid() = user_id);

-- Financial Transactions
create table if not exists financial_transactions (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  type text check (type in ('income','expense')) not null,
  category text not null,
  amount numeric(12,2) not null check (amount > 0),
  description text,
  date date not null,
  created_at timestamptz default now() not null
);

alter table financial_transactions enable row level security;
create policy "Users can manage own transactions" on financial_transactions for all using (auth.uid() = user_id);

-- Financial Goals
create table if not exists financial_goals (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  title text not null,
  target_amount numeric(12,2) not null,
  current_amount numeric(12,2) default 0,
  deadline date,
  created_at timestamptz default now() not null
);

alter table financial_goals enable row level security;
create policy "Users can manage own goals" on financial_goals for all using (auth.uid() = user_id);

-- Sleep Logs
create table if not exists sleep_logs (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  date date not null,
  hours_slept numeric(4,1) not null,
  sleep_quality integer check (sleep_quality between 1 and 5) not null,
  notes text,
  created_at timestamptz default now() not null,
  unique(user_id, date)
);

alter table sleep_logs enable row level security;
create policy "Users can manage own sleep logs" on sleep_logs for all using (auth.uid() = user_id);

-- Mental Exercise Results
create table if not exists mental_exercise_results (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  exercise_type text check (exercise_type in ('memory_sequence','reaction_time','focus_match')) not null,
  score integer not null,
  accuracy integer not null,
  reaction_time integer,
  created_at timestamptz default now() not null
);

alter table mental_exercise_results enable row level security;
create policy "Users can manage own exercise results" on mental_exercise_results for all using (auth.uid() = user_id);

-- Cognitive Daily Status
create table if not exists cognitive_daily_status (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  date date not null,
  cognitive_score integer not null,
  focus_score integer not null,
  fatigue_score integer not null,
  burnout_risk integer not null,
  ai_summary text,
  created_at timestamptz default now() not null,
  unique(user_id, date)
);

alter table cognitive_daily_status enable row level security;
create policy "Users can manage own cognitive status" on cognitive_daily_status for all using (auth.uid() = user_id);

-- AI Messages
create table if not exists ai_messages (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  role text check (role in ('user','assistant')) not null,
  message text not null,
  created_at timestamptz default now() not null
);

alter table ai_messages enable row level security;
create policy "Users can manage own ai messages" on ai_messages for all using (auth.uid() = user_id);

-- Indexes for performance
create index if not exists idx_tasks_user on tasks(user_id);
create index if not exists idx_events_user on calendar_events(user_id);
create index if not exists idx_transactions_user on financial_transactions(user_id);
create index if not exists idx_sleep_user on sleep_logs(user_id, date desc);
create index if not exists idx_exercises_user on mental_exercise_results(user_id, created_at desc);
create index if not exists idx_cognitive_user on cognitive_daily_status(user_id, date desc);
create index if not exists idx_ai_messages_user on ai_messages(user_id, created_at asc);

-- Onboarding flag
alter table profiles add column if not exists onboarding_done boolean default false;
