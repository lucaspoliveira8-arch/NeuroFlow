import { createClient } from "@/lib/supabase/client";
import type { AIMessage } from "@/types";

const sb = () => createClient();

export const AIMessagesService = {
  async list(): Promise<AIMessage[]> {
    const { data, error } = await sb()
      .from("ai_messages")
      .select("*")
      .order("created_at", { ascending: true })
      .limit(100);
    if (error) throw error;
    return data ?? [];
  },

  async save(role: "user" | "assistant", message: string): Promise<AIMessage> {
    const {
      data: { user },
    } = await sb().auth.getUser();
    if (!user) throw new Error("Not authenticated");

    const { data, error } = await sb()
      .from("ai_messages")
      .insert({ user_id: user.id, role, message })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async clearHistory(): Promise<void> {
    const {
      data: { user },
    } = await sb().auth.getUser();
    if (!user) throw new Error("Not authenticated");
    const { error } = await sb()
      .from("ai_messages")
      .delete()
      .eq("user_id", user.id);
    if (error) throw error;
  },
};
