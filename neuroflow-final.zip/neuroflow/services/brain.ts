import { createClient } from "@/lib/supabase/client";
import type { SleepLog, MentalExerciseResult, CognitiveDailyStatus } from "@/types";

const sb = () => createClient();

export const BrainService = {
  async listSleepLogs(): Promise<SleepLog[]> {
    const { data, error } = await sb()
      .from("sleep_logs")
      .select("*")
      .order("date", { ascending: false })
      .limit(30);
    if (error) throw error;
    return data ?? [];
  },

  async logSleep(
    payload: Omit<SleepLog, "id" | "user_id" | "created_at">
  ): Promise<SleepLog> {
    const {
      data: { user },
    } = await sb().auth.getUser();
    if (!user) throw new Error("Not authenticated");
    const { data, error } = await sb()
      .from("sleep_logs")
      .upsert({ ...payload, user_id: user.id }, { onConflict: "user_id,date" })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async listExerciseResults(): Promise<MentalExerciseResult[]> {
    const { data, error } = await sb()
      .from("mental_exercise_results")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) throw error;
    return data ?? [];
  },

  async saveExerciseResult(
    payload: Omit<MentalExerciseResult, "id" | "user_id" | "created_at">
  ): Promise<MentalExerciseResult> {
    const {
      data: { user },
    } = await sb().auth.getUser();
    if (!user) throw new Error("Not authenticated");
    const { data, error } = await sb()
      .from("mental_exercise_results")
      .insert({ ...payload, user_id: user.id })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async getLatestCognitiveStatus(): Promise<CognitiveDailyStatus | null> {
    const { data, error } = await sb()
      .from("cognitive_daily_status")
      .select("*")
      .order("date", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async saveCognitiveStatus(
    payload: Omit<CognitiveDailyStatus, "id" | "user_id" | "created_at">
  ): Promise<CognitiveDailyStatus> {
    const {
      data: { user },
    } = await sb().auth.getUser();
    if (!user) throw new Error("Not authenticated");
    const { data, error } = await sb()
      .from("cognitive_daily_status")
      .upsert({ ...payload, user_id: user.id }, { onConflict: "user_id,date" })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async listCognitiveHistory(): Promise<CognitiveDailyStatus[]> {
    const { data, error } = await sb()
      .from("cognitive_daily_status")
      .select("*")
      .order("date", { ascending: false })
      .limit(30);
    if (error) throw error;
    return data ?? [];
  },
};
