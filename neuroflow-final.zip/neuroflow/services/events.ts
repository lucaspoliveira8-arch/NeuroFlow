import { createClient } from "@/lib/supabase/client";
import type { CalendarEvent } from "@/types";

const sb = () => createClient();

export const EventsService = {
  async list(): Promise<CalendarEvent[]> {
    const { data, error } = await sb()
      .from("calendar_events")
      .select("*")
      .order("start_time", { ascending: true });
    if (error) throw error;
    return data ?? [];
  },

  async create(
    payload: Omit<CalendarEvent, "id" | "user_id" | "created_at">
  ): Promise<CalendarEvent> {
    const {
      data: { user },
    } = await sb().auth.getUser();
    if (!user) throw new Error("Not authenticated");

    const { data, error } = await sb()
      .from("calendar_events")
      .insert({ ...payload, user_id: user.id })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async update(
    id: string,
    payload: Partial<CalendarEvent>
  ): Promise<CalendarEvent> {
    const { data, error } = await sb()
      .from("calendar_events")
      .update(payload)
      .eq("id", id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async delete(id: string): Promise<void> {
    const { error } = await sb()
      .from("calendar_events")
      .delete()
      .eq("id", id);
    if (error) throw error;
  },
};
