import { createClient } from "@/lib/supabase/client";
import type { FinancialTransaction, FinancialGoal } from "@/types";

const sb = () => createClient();

export const FinancesService = {
  async listTransactions(): Promise<FinancialTransaction[]> {
    const { data, error } = await sb()
      .from("financial_transactions")
      .select("*")
      .order("date", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },

  async createTransaction(
    payload: Omit<FinancialTransaction, "id" | "user_id" | "created_at">
  ): Promise<FinancialTransaction> {
    const {
      data: { user },
    } = await sb().auth.getUser();
    if (!user) throw new Error("Not authenticated");
    const { data, error } = await sb()
      .from("financial_transactions")
      .insert({ ...payload, user_id: user.id })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async deleteTransaction(id: string): Promise<void> {
    const { error } = await sb()
      .from("financial_transactions")
      .delete()
      .eq("id", id);
    if (error) throw error;
  },

  async listGoals(): Promise<FinancialGoal[]> {
    const { data, error } = await sb()
      .from("financial_goals")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },

  async createGoal(
    payload: Omit<FinancialGoal, "id" | "user_id" | "created_at">
  ): Promise<FinancialGoal> {
    const {
      data: { user },
    } = await sb().auth.getUser();
    if (!user) throw new Error("Not authenticated");
    const { data, error } = await sb()
      .from("financial_goals")
      .insert({ ...payload, user_id: user.id })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async updateGoal(
    id: string,
    payload: Partial<FinancialGoal>
  ): Promise<FinancialGoal> {
    const { data, error } = await sb()
      .from("financial_goals")
      .update(payload)
      .eq("id", id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async deleteGoal(id: string): Promise<void> {
    const { error } = await sb()
      .from("financial_goals")
      .delete()
      .eq("id", id);
    if (error) throw error;
  },

  computeSummary(transactions: FinancialTransaction[]) {
    const income = transactions
      .filter((t) => t.type === "income")
      .reduce((s, t) => s + t.amount, 0);
    const expense = transactions
      .filter((t) => t.type === "expense")
      .reduce((s, t) => s + t.amount, 0);
    return { income, expense, balance: income - expense };
  },
};
