import { createClient } from "@/lib/supabase/client";
import type { Profile } from "@/types";

const sb = () => createClient();

export const ProfileService = {
  async get(): Promise<Profile | null> {
    const { data: { user } } = await sb().auth.getUser();
    if (!user) return null;
    const { data, error } = await sb()
      .from("profiles").select("*").eq("id", user.id).maybeSingle();
    if (error) throw error;
    return data;
  },

  async upsert(fullName: string): Promise<Profile> {
    const { data: { user } } = await sb().auth.getUser();
    if (!user) throw new Error("Not authenticated");
    const { data, error } = await sb()
      .from("profiles")
      .upsert({ id: user.id, full_name: fullName, email: user.email })
      .select().single();
    if (error) throw error;
    return data;
  },
};
