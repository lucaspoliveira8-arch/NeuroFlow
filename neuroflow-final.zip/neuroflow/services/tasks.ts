import { createClient } from "@/lib/supabase/client";
import type { Task, TaskStatus, TaskPriority } from "@/types";

const sb = () => createClient();

export const TasksService = {
  async list(): Promise<Task[]> {
    const { data, error } = await sb()
      .from("tasks")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },

  async create(
    payload: Omit<Task, "id" | "user_id" | "created_at">
  ): Promise<Task> {
    const {
      data: { user },
    } = await sb().auth.getUser();
    if (!user) throw new Error("Not authenticated");

    const { data, error } = await sb()
      .from("tasks")
      .insert({ ...payload, user_id: user.id })
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async update(id: string, payload: Partial<Task>): Promise<Task> {
    const { data, error } = await sb()
      .from("tasks")
      .update(payload)
      .eq("id", id)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  async delete(id: string): Promise<void> {
    const { error } = await sb().from("tasks").delete().eq("id", id);
    if (error) throw error;
  },

  async toggleStatus(task: Task): Promise<Task> {
    const next: TaskStatus =
      task.status === "done"
        ? "todo"
        : task.status === "todo"
        ? "in_progress"
        : "done";
    return this.update(task.id, { status: next });
  },
};
