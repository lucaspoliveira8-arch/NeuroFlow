import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ["var(--font-inter)", "system-ui", "sans-serif"],
        display: ["var(--font-cal)", "var(--font-inter)", "sans-serif"],
        mono: ["var(--font-mono)", "monospace"],
      },
      colors: {
        // Dark mode surfaces
        surface: {
          base: "#0a0b0f",
          subtle: "#0f1117",
          raised: "#141720",
          overlay: "#1a1f2e",
          border: "rgba(255,255,255,0.06)",
          "border-strong": "rgba(255,255,255,0.10)",
        },
        // Light mode surfaces  
        light: {
          base: "#f8f9fc",
          subtle: "#f1f3f8",
          raised: "#ffffff",
          overlay: "#ffffff",
          border: "rgba(0,0,0,0.07)",
          "border-strong": "rgba(0,0,0,0.12)",
        },
        // Accent - electric blue
        accent: {
          50: "#eff6ff",
          100: "#dbeafe",
          200: "#bfdbfe",
          300: "#93c5fd",
          400: "#60a5fa",
          500: "#3b82f6",
          600: "#2563eb",
          700: "#1d4ed8",
          DEFAULT: "#3b82f6",
          muted: "rgba(59,130,246,0.12)",
          border: "rgba(59,130,246,0.25)",
        },
        // Violet - secondary
        violet: {
          DEFAULT: "#7c3aed",
          soft: "#a78bfa",
          muted: "rgba(124,58,237,0.10)",
        },
        // Semantic
        emerald: {
          DEFAULT: "#10b981",
          muted: "rgba(16,185,129,0.12)",
        },
        rose: {
          DEFAULT: "#f43f5e",
          muted: "rgba(244,63,94,0.10)",
        },
        amber: {
          DEFAULT: "#f59e0b",
          muted: "rgba(245,158,11,0.10)",
        },
      },
      spacing: {
        sidebar: "232px",
      },
      borderRadius: {
        card: "14px",
        modal: "16px",
        btn: "8px",
        tag: "6px",
      },
      boxShadow: {
        card: "0 1px 2px rgba(0,0,0,0.08), 0 0 0 1px rgba(255,255,255,0.05)",
        "card-light": "0 1px 3px rgba(0,0,0,0.06), 0 0 0 1px rgba(0,0,0,0.06)",
        "card-hover": "0 4px 16px rgba(0,0,0,0.2), 0 0 0 1px rgba(255,255,255,0.07)",
        modal: "0 24px 64px rgba(0,0,0,0.5)",
        "modal-light": "0 16px 48px rgba(0,0,0,0.12)",
        focus: "0 0 0 3px rgba(59,130,246,0.25)",
        "accent-glow": "0 4px 24px rgba(59,130,246,0.18)",
      },
      fontSize: {
        "2xs": ["10px", "14px"],
      },
      animation: {
        "fade-up": "fadeUp 0.35s cubic-bezier(0.16,1,0.3,1)",
        "fade-in": "fadeIn 0.25s ease-out",
        "slide-in-left": "slideInLeft 0.3s cubic-bezier(0.16,1,0.3,1)",
        "scale-in": "scaleIn 0.2s cubic-bezier(0.16,1,0.3,1)",
        "pulse-soft": "pulseSoft 3s ease-in-out infinite",
        "shimmer": "shimmer 1.8s linear infinite",
      },
      keyframes: {
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideInLeft: {
          "0%": { opacity: "0", transform: "translateX(-8px)" },
          "100%": { opacity: "1", transform: "translateX(0)" },
        },
        scaleIn: {
          "0%": { opacity: "0", transform: "scale(0.96)" },
          "100%": { opacity: "1", transform: "scale(1)" },
        },
        pulseSoft: {
          "0%,100%": { opacity: "0.6" },
          "50%": { opacity: "1" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
    },
  },
  plugins: [],
};
export default config;
