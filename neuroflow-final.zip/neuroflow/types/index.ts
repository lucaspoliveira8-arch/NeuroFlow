export type TaskStatus = "todo" | "in_progress" | "done";
export type TaskPriority = "low" | "medium" | "high" | "urgent";
export type TransactionType = "income" | "expense";
export type SleepQuality = 1 | 2 | 3 | 4 | 5;
export type ExerciseType = "memory_sequence" | "reaction_time" | "focus_match";
export type MessageRole = "user" | "assistant";

export interface Profile {
  id: string;
  full_name: string | null;
  email: string | null;
  created_at: string;
}

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  due_date: string | null;
  priority: TaskPriority;
  category: string | null;
  status: TaskStatus;
  created_at: string;
}

export interface CalendarEvent {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  start_time: string;
  end_time: string;
  created_at: string;
}

export interface FinancialTransaction {
  id: string;
  user_id: string;
  type: TransactionType;
  category: string;
  amount: number;
  description: string | null;
  date: string;
  created_at: string;
}

export interface FinancialGoal {
  id: string;
  user_id: string;
  title: string;
  target_amount: number;
  current_amount: number;
  deadline: string | null;
  created_at: string;
}

export interface SleepLog {
  id: string;
  user_id: string;
  date: string;
  hours_slept: number;
  sleep_quality: SleepQuality;
  notes: string | null;
  created_at: string;
}

export interface MentalExerciseResult {
  id: string;
  user_id: string;
  exercise_type: ExerciseType;
  score: number;
  accuracy: number;
  reaction_time: number | null;
  created_at: string;
}

export interface CognitiveDailyStatus {
  id: string;
  user_id: string;
  date: string;
  cognitive_score: number;
  focus_score: number;
  fatigue_score: number;
  burnout_risk: number;
  ai_summary: string | null;
  created_at: string;
}

export interface AIMessage {
  id: string;
  user_id: string;
  role: MessageRole;
  message: string;
  created_at: string;
}

export interface CognitiveMetrics {
  cognitiveScore: number;
  focusScore: number;
  fatigueScore: number;
  burnoutRisk: number;
}
